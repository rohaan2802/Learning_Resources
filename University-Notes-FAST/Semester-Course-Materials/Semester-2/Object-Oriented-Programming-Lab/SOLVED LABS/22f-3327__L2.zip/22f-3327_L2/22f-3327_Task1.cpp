//// in this program , addresses and values of indexes of an array are printed using increment and decrement operator.
//// Also the values of array are compared using pointers 
////After every process the pointer is initialized with startying address of array otherwise it store the previous address and cause error
//#include<iostream >
//using namespace std;
//int main()
//{
//	int arr[5] = { 3,9,1,15,3 };
//	int *ptr;
//	ptr = arr;
//	//--------------using increment operator ----------
//	cout << "\n using INCREMENT OPERATOR \n";
//	for (int i = 0; i < 5;i++)
//	{
//		cout << "\n address of  " << i << "th index is " << ptr;
//		cout << "\n value  of  " << i << "th index is " << *ptr;
//		ptr++;
//	}
//	ptr = &arr[4];
//	//--------------using decrement operator ----------
//	cout << "\n\n using DECREMENT OPERATOR \n";
//	for (int i = 4; i>-1;i--)
//	{
//		cout << "\n address of  " << i << "th index is " << ptr;
//		cout << "\n value  of  " << i << "th index is " << *ptr;
//		ptr--;
//	}
//	//--------------- checking for equal------------------ 
//	ptr = arr;
//	cout << "\n\n checking for equal elemets in array \n";
//	for (int i = 0; i < 5; ++i)
//	{
//		for (int j = i + 1; j < 5; ++j)
//		{
//			if (ptr[i] == ptr[j])
//			{
//				cout << "\n same values that is " <<ptr[i] <<" at " << i << " and " << j << " index ";
//			}
//		}
//	}
//	system("pause");
//	return 0;
//}