#include<iostream >
using namespace std;
void Print(int** ptr);
int main()
{
	int **array = new int*[3];	// using DMA . inside this double pointer of 3 arrays there is again array of 3 at every point
	for (int i = 0; i < 3; ++i)
	{
		array[i] = new int [3];
	}
	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			array[i][j] = i + j;
		}
	}
	Print(array);

	system("pause");
	return 0;
}
void Print(int** ptr)
{
	for (int i = 0; i < 3; ++i)
	{
		cout << endl;
		for (int j = 0; j < 3; ++j)
		{
			cout << ptr[i][j] << " ";
		}
	}
}