//#include<iostream >
//using namespace std;
//bool primaryCheck(int* ptr);
//int main()
//
//{
//	int num;
//	cout << "\n Enter a number : " ;// input from user 
//	cin >> num;
//	int *ptrnum = &num;		// initializing pointer 
//	  function call
//	if (primaryCheck(ptrnum))		// if function returns true then prime number otherwise not 
//	{
//		cout << "\n Prime number ";
//	}
//	else
//	{
//		cout << "\n Not prime number ";
//	}
//	cout << endl;
//	system("pause");
//	return 0;
//}
//bool primaryCheck(int* ptr)
//{
//	for (int i =2; i < *ptr / 2; ++i)
//	{
//		if (*ptr%i == 0)
//			return false;		// if at any moment the number is divisible by any number it returns false 
//	}
//	return true;
//}