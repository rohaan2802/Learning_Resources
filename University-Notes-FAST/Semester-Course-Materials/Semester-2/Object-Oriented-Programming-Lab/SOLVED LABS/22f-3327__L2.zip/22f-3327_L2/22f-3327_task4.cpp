//#include<iostream >
//#include<iomanip>
//using namespace std;
//int main()
//{
//	// part a : initializing an array of type double 
//	const int Size = 10;
//	double numbers[Size] = { 0.0,1.1,2.2,3.3,4.4,5.5,6.6,7.7,8.8,9.9 };
//	// part b:Declare a pointer nPtr that points to a variable of type double.
//	double num=13.69;
//	double *nPtr = &num;
//	//part c: for statement to print the elements of array numbers using array subscript notation.
//	//        Print each number with one position of precision to the right of the decimal point.
//	cout << "\n\n\n subscript notation ";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << setprecision(1) << fixed;
//		cout << "\n Element at " << i << "th index is " << numbers[i];
//	}
//	//part d: two separate statements that each assign the starting address of array numbers to the
//	//        pointer variable nPtr.
//	nPtr = numbers;
//	nPtr = &numbers[0];
//	// part e: a for statement to print the elements of array numbers using pointer/offset notation with
//    //       	pointer nPtr.
//	cout << "\n\n\n Offset notaion with pointer ";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << "\n Element at " << i << "th index is " << *(nPtr+i);
//	}
//	// part f:a for statement to print the elements of array numbers using pointer/offset notation with
//	//        the array name as the pointer.
//	cout << "\n\n\n Offset notaion with array name as pointer ";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << "\n Element at " << i << "th index is " << *( numbers + i);
//	}
//	// part g: Use a for statement to print the elements of array numbers using pointer/subscript notation
//	//         with pointer nPtr.
//	cout << "\n\n\n Subscript notation with pointer nPtr ";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << "\n Element at " << i << "th index is " <<nPtr[i];
//	}
//	// part h:Refer to the fourth element of array numbers using different ways 
//	cout << "\n\n\n Element 4 using array subscript notation:" << numbers[3];
//	cout << "\n Element 4 using offset notation with array name   :" << *(numbers+3);
//	cout << "\n Element 4 using pointyer subscript notation  :" << nPtr[3];
//	cout << "\n Element 4 using offset notation with  pointer:" << *(nPtr+3);
//	// part i:nPtr points to the beginning of array numbers, what address is referenced by
//	//        nPtr + 8 ? What value is stored at that location ?
//	nPtr = numbers;
//	cout << "\n\n\n Address of 9th element is  "<<nPtr+8;
//	cout << "\n Value of 9th element is " << *(nPtr + 8);
//	// part j: nPtr points to the beginning of array numbers, what address is referenced by
//	//         nPtr + 8 ? What value is stored at that location ?
//	nPtr = &numbers[5];
//	nPtr -= 4;
//	cout << "\n\n\n Address of 1st element is " << nPtr;
//	cout << "\n value of 1st element is : " << *nPtr;
//	cout << endl;
//	system("pause");
//	return 0;
//}