//// program perform multiple tasks with pointers 
//#include<iostream >
//using namespace std;
//int main()
//{
//	int firstvalue = 15, secondvalue = 25;
//	int * p1, *p2, **p3, **p4;
//	p1 = &firstvalue;										 // p1 = address of firstvalue
//	p2 = &secondvalue;										 // p2 = address of secondvalue
//	p3 = &p1;										 // p3 = address of firstpointrer
//	p4 = &p2;										 // p4 = address of secondpointer
//	*p1 = 100;										 // value pointed by p1 = 100
//	*p2 = *p1;										 // value pointed by p2 = value pointed by p1
//	 p1 = p2;										 // p1 = p2 (address of pointer is copied or not)
//	cout << "\n value of p1 is " << p1 << " and value of p2 is " << p2;
//	p3 = p4;										 // p3 =p4 (check address of pointer is copied or not)
//	if (p3 == p4)
//	{
//		cout << "\n\n\n value of p3 is " << p3 << " and value of p4 is " << p4;
//		cout << "\n Address copied of p3 and p4 ";
//	}
//	else 
//		cout << "\n Address NOT copied ";
//	*p1 = 200;										 // value pointed by p1 = 200
//	cout << "\n\n\n first value is "<<firstvalue<<" and second value is  "<<secondvalue  ;	// print firstvalue, secondvalue
//	cout << endl;
//	system("pause");
//	return 0;
//}