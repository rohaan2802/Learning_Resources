///*	Dynamic array declared in main function . 
//	its value copied into another dynamic array and address of copied array stored in a pointer 
//	at last memory of dynamic array in main function is released and Nulled for future use
// 
//*/
//#include<iostream>
//using namespace std;
//int *copyFun(int arr[], int  Size);
//int main()
//{
//	const int Size = 5;
//	int* ptr1;
//	int *array=new int [Size];
//	cout << "Enter elements of array : \n";
//	for (int i = 0; i< Size; ++i)	// initializing array
//	{
//		cin >> array[i];
//	}
//	ptr1=copyFun(array, Size);//address of copied array stored in pointer
//	 delete[] array; 
//	 array = NULL;
//	cout << "\n copied array address is : " << ptr1;
//	cout << endl;
//	system("pause");
//	return 0;
//}
//int *copyFun(int arr[], int  Size)
//{
//	int* copy_array = new int[Size];
//	for (int i = 0; i < Size; ++i)	// array from main fuction copied into another array
//	{
//		copy_array[i] = arr[i];
//	}
//	return copy_array;// addres of copied array returned to pointer in main function
//
//}