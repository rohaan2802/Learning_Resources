///* this program takes iput of two  matrices from user and add them and store in a 
//   third dynamic array . its checks whether order is same or not . all matrices are 
//   stored in dynamic memory .
//*/
//#include<iostream>
//#include<iomanip>
//using namespace std;
//
//void Input(int**, int, int);
//int** Sum(int**, int, int, int**, int, int);
//void Display(int**, int, int);
//
//int main()
//{
//	int row1, col1, row2, col2;
//
//	cout << "Enter number of rows of matrix 1: ";
//	cin >> row1;
//	cout << "Enter number of columns matrix 1: ";
//	cin >> col1;
//	// declaring the matrix 1 with double pointers dynamic allocation
//	int** matrix1 = new int* [row1];
//	for (int i = 0; i < row1; i++) 
//	{
//		matrix1[i] = new int[col1];
//	}
//	Input(matrix1, row1, col1);
//
//	cout << "Enter number of rows of matrix 2: ";
//	cin >> row2;
//	cout << "Enter number of columns matrix 2: ";
//	cin >> col2;
//	// declaring the matrix 2 with double pointers dynamic allocation
//	int** matrix2 = new int* [row2];
//	for (int i = 0; i < row2; i++)
//	{
//		matrix2[i] = new int[col2];
//	}
//	Input(matrix2, row2, col2);
//	// sum of matrix 1 and 2
//	int** ptr = Sum(matrix1, row1, col2, matrix2, row2, col2);// address  of sumed matrix stored in a pointer
//	// display the sum of matrix 
//	if (row1 == row2 && col1 == col2)// if order of both matrices equal
//	{
//		cout << "\nMatrix 1 is :\n";
//		Display(matrix1, row1, col2);
//		cout << "\nMatrix 2 is :\n";
//		Display(matrix2, row2, col2);
//		cout << "SUM OF Matrix 1 and 2 is \n";
//		Display(ptr, row1, col2);
//	} 
//	else            // if order not same exit program 	
//	{
//		cout << "\nORDER OF MATRIX 1 AND MATRIX 2 NOT EQUAL .";
//		return 99;
//	}
//	cout << endl;
//	system("pause");
//	return 0;
//}
//
//void Input(int** arr, int row, int col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			cout << "Enter value of index  a"<<i+1<<j+1<<" :";
//			cin >> arr[i][j];
//		}
//	}
//}
//
//int** Sum(int** p, int row, int col, int** q, int row2, int col2) {
//	if (row == row2 && col == col2) 
//	{
//		// making new matrix c to store sum of matrix1 and matrix2
//		int** c = new int* [row];
//		for (int i = 0; i < row; i++) 
//		{
//			c[i] = new int[col];
//		}
//		// calculating sum
//		for (int i = 0; i < row; i++) 
//		{
//			for (int j = 0; j < col; j++) 
//			{
//				c[i][j] = p[i][j] + q[i][j];
//			}
//		}
//		return c;
//	}
//	else 
//	{
//			cout << "Order of Matrix 1 and Matrix 2 is not equal\n";
//		return 0;
//	}
//}
//
//void Display(int** arr, int row, int col) 
//{
//
//	for (int i = 0; i < row; i++)
//	{
//		cout << "     ";
//		for (int j = 0; j < col; j++)
//		{
//			cout <<setw(4) << " " << arr[i][j];
//		}
//			cout << endl;
//	}
//}
//
