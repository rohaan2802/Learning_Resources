///* This program initialise a 2D array and take input from user using pointer ptr
//	then add 100 in each entry and at the end print in 2D matrix form using pointer
//*/
//#include<iostream>
//using namespace std;
//int main()
//{
//	const int Size = 2;
//	int array[Size][Size];	// array declared
//	int (*ptr)[Size];
//	ptr = array;
//	cout << "Enter elements of matrix :\n";
//	for (int i = 0; i < Size; ++i)	// input from user 
//	{
//		for (int j = 0; j < Size; ++j)
//		{
//			cin >> *(*(ptr + i) + j);		// pointer used . 'i' indicates row and 'j' indicates column.
//		}
//	}
//	for (int i = 0; i < Size; ++i)	// adding 100 in each entry
//	{
//		for (int j = 0; j < Size; ++j)
//		{
//			*(*(ptr + i) + j) += 100;
//		}
//	}
//	cout << "\n\nmatrix after adding hundred in its each entry : \n\n";
//	for (int i = 0; i < Size; ++i)	// printing 2D array in matrix form 
//	{
//		for (int j = 0; j < Size; ++j)
//		{
//			cout<< *(*(ptr + i) + j)<<"  ";
//		}
//		cout << endl;
//	}
//	system("pause");
//	return 0;
//}