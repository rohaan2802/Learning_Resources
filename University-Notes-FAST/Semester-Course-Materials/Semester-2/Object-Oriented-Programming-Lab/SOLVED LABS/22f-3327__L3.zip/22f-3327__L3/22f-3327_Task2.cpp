///* this program declares a dynamic pointer array 
// value is initialised using a loop 
// at the end using PrintFunction array is printed */
//#include<iostream>
//using namespace std;
//void PrintFunction(int* a);
//int main()
//{
//	int *a = new int [5];	// Using  new to make a point to a dynamic array of 5 cells of type int.
//	for (int i = 0,j=3; i < 5; ++i,j+=4)	//loop to fill a with values 3, 7, 11, 15, 19.
//	{
//		a[i] = j;
//	}
//	PrintFunction(a);	// calling PrintFunction to print array from heap
//	cout << endl;
//	system("pause");
//	return 0;
//}
//void PrintFunction(int *address)
//{
//	cout << "\n Printed array is:\n";
//	for (int i = 0; i < 5; ++i)
//	{
//		cout << *(address+i)<<" ";
//	}
//}