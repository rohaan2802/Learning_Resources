#include <iostream>
using namespace std;

void input(int**, int*, int);
void display(int**, int*, int);

int main() 
{
	int n;
	cout << "Number of rows : ";
	cin >> n;
	// making double pointer and dynamic allocation of memory 
	int** array = new int* [n];
	int* cols = new int[n];// columns of each row . can be different for every row
	for (int i = 0; i < n; i++) 
	{
		cout << "Enter number of columns for row " << i << " : ";
		cin >> cols[i];
		array[i] = new int[cols[i]];// specifying columns for each row based on input 
	}
	// calling the functions
	input(array, cols, n);
	display(array, cols, n);
	// deallocation of array
	delete[]array;
	delete[]cols;
	cout << endl;
	system("pause");
	return 0;
}

void input(int** array, int* cols, int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < cols[i]; j++) 
		{
			cout << "Row " << i << " col " << j << " Enter input: ";
			cin >> array[i][j];
		}
	}
}

void display(int** array, int* cols, int n) 
{
	cout << "\nDisplaying array   \n";
	
	for (int i = 0; i < n; i++) 
	{
		cout << "     ";
		for (int j = 0; j < cols[i]; j++)
		{
			cout << array[i][j] << "  ";
		}
		cout << endl;
	}
	
}
