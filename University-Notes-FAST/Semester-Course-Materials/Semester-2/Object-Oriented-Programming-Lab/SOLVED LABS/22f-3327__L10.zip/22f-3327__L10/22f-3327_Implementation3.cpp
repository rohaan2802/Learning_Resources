#include<iostream>
#include"22F-3327_Interface3.h"
using namespace std;
//SocialMedia CLASS functions definitions
SocialMedia::SocialMedia()
{
	cout << "Social Media is opened" << endl;
}
void SocialMedia::post()
{
	cout << "SocialMedia post shared " << endl;
}
void SocialMedia::share()
{
	cout << "SocialMedia sharing is caring " << endl;
}
void SocialMedia::sort()
{
	cout << "SocialMedia posts are SORTED  " << endl;
}
void SocialMedia::filter()
{
	cout << "SocialMedia reels are FILTERED  " << endl;
}

//Text CLASS and functions definitions
Text::Text()
{
	cout << "text/Bio of user " << endl;
}
void Text::post()
{
	cout << "Tweeted  a Text" << endl;
}
void Text::share()
{
	cout << " Shared a message / text with daddy  " << endl;
}
void  Text::sort()
{
	cout << " Messages were SORTED   " << endl;
}
void  Text::filter()
{
	cout << "TEXT was FILTERED   " << endl;
}

//Photos CLASS functions definitions
Photos::Photos()
{
	cout << "Photo is captured " << endl;
}
void Photos::post()
{
	cout << "Posted a Photo" << endl;
}
void Photos::share()
{
	cout << "Shared a Photo with sir Hannan " << endl;
}
void Photos::sort()
{
	cout << " PHOTOS were SORTED   " << endl;
}
void Photos::filter()
{
	cout << " PHOTOS were FILTERED   " << endl;
}

//Videos CLASS functions definitions
Videos::Videos()
{
	cout << "Video is created" << endl;
}
void Videos::post()
{
	cout << "Posted a Video" << endl;
}
void Videos::share()
{
	cout << "Shared a Video with BALOCH" << endl;
}
void Videos::sort()
{
	cout << " Videos were sorted   " << endl;
}
void Videos::filter()
{
	cout << "Videos were applied FILTER on" << endl;
}