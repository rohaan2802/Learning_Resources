//#pragma once
//#include<string>
//using namespace std;
//class Animals
//{
//public: 
//	string Name;
//	Animals();
//	Animals(string);
//	void Sound();
//};
//class Cat : public Animals 
//{
//public:
//	Cat();
//	Cat(string);
//	void Sound();
//};
//class Dog : public Animals
//{
//public:
//	Dog();
//	Dog(string);
//	void Sound();
//};
//class Tiger_Family : public Animals
//{
//public: 
//	Tiger_Family();
//	Tiger_Family(string);
//	void Sound();
//};
//class Deer : public Animals
//{
//public:
//	Deer();
//	Deer(string);
//	void Sound();
//};
//class Tiger : public Tiger_Family
//{
//public:
//	Tiger();
//	Tiger(string);
//	void Sound();
//};
//class Lion : public Tiger_Family
//{
//public:
//	Lion();
//	Lion(string);
//	void Sound();
//};
