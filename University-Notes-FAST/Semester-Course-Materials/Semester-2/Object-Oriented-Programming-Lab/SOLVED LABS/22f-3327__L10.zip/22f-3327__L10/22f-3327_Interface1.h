//#pragma once
//class Person
//{
//	//Data members of Person
//public:
//	Person();
//	Person(int x);
//};
//class Faculty :virtual public Person
//{
//	//data members of Faculty
//public:
//	Faculty(int x);
//};
//class Student : virtual public Person
//{
//	//data members of Student
//public:
//	Student(int x);
//};
//
//class TA : public Faculty, public Student
//{
//public:
//	TA(int x);
//};
//
