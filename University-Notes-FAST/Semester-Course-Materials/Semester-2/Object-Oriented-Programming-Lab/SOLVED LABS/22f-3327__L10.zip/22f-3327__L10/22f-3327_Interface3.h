#pragma once
#include<iostream>
using namespace std;
class SocialMedia
{
	
public:
	SocialMedia();
	void post();
	void share();
	void sort();
	void filter();
};

class Text : public SocialMedia
{

public:
	Text();
	void post();
	void share();
	void sort();
	void filter();
};

class Photos : public SocialMedia
{

public:
	Photos();
	void post();
	void share();
	void sort();
	void filter();
};

class Videos : public SocialMedia
{
	
public:
	Videos();
	void post();
	void share();
	void sort();
	void filter();
};
