#include<iostream>
#include"22F-3327_Interface3.h"
using namespace std;
int main()
{
	SocialMedia socialMedia;
	socialMedia.post();
	socialMedia.share();
	socialMedia.sort();
	socialMedia.filter();
	cout << "\n\n\n";
	Text text;
	text.post();
	text.share();
	text.sort();
	text.filter();
	cout << "\n\n\n";
	Photos photos;
	photos.post();
	photos.share();
	photos.sort();
	photos.filter();
	cout << "\n\n\n";
	Videos video;
	video.post();
	video.share();
	video.sort();
	video.filter();
	return 0;
}