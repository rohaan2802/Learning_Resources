//#include<iostream>
//#include"22f-3327_Interface2.h"
//using namespace std;
//int main()
//{
//	Animals animal;
//	cout << endl;
//	Cat cat;
//	cout << endl;
//	Dog dog;
//	cout << endl;
//	Tiger_Family tiger_Family;
//	cout << endl;
//	Deer deer;
//	cout << endl;
//	Tiger tiger;
//	cout << endl;
//	Lion lion;
//	cout << endl;
//	cout << "\n==================================================";
//	animal.Sound();
//	cat.Sound();
//	dog.Sound();
//	tiger_Family.Sound();
//	deer.Sound();
//	tiger.Sound();
//	lion.Sound();
//	cout << endl;
//	system("pause");
//	return 0;
//}