//#include"22f-3327_Interface2.h"
//#include<string>
//#include<iostream>
//using namespace std;
//
//Animals::Animals() :Name("") { cout << "\nAnimals::Animals() called "; }
//
//Animals::Animals(string name)
//{
//	this->Name = name;
//}
//void Animals::Sound()
//{
//	cout << "\nAnimal sound ";
//}
//Cat::Cat() { cout << "\nCat::Cat() called"; }
//Cat::Cat(string name) :Animals(name) {}
//void Cat::Sound()
//{
//	cout << "\n Cat sound is Meow Meow ";
//}
//
//
//Dog::Dog() { cout << "\nDog::Dog() called"; }
//Dog::Dog(string name) :Animals(name) {}
//void Dog::Sound()
//{
//	cout << "\n Dog  sound is Woff Woff ";
//}
//
//
//Tiger_Family::Tiger_Family() { cout << "\nTiger_Family::Tiger_Family() called"; }
//Tiger_Family::Tiger_Family(string name) :Animals(name) {}
//void Tiger_Family::Sound()
//{
//	cout << "\n Tiger Family sound is Roar ";
//}
//
//
//Deer::Deer() { cout << "\nDeer::Deer() called"; }
//Deer::Deer(string name) :Animals(name) {}
//void Deer::Sound()
//{
//	cout << "\n Deer sound is Bleat ";
//}
//
//
//Tiger::Tiger() { cout << "\nTiger::Tiger() called"; }
//Tiger::Tiger(string name) :Tiger_Family(name) {}
//void Tiger::Sound()
//{
//	cout << "\n Tiger sound is Chuff ";
//}
//
//
//Lion::Lion() { cout << "\nLion::Lion() called"; }
//Lion::Lion(string name) :Tiger_Family(name) {}
//void Lion::Sound()
//{
//	cout <<"\n Lion sound is Growl ";
//}
//
