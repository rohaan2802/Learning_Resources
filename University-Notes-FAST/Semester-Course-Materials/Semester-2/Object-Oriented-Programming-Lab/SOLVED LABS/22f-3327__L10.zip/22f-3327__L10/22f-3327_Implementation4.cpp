//#include<iostream>
//#include"22f-3327_Interface4.h"
//using namespace std;
//
//	Time::Time()
//	{
//		hr = 0;
//		min = 0;
//	}
//	Time::Time(int hour, int minutes)
//	{
//		hr = hour;
//		min = minutes;
//	}
//	void Time::setTime(int hour = 0, int minutes = 0)
//	{
//		hr = hour;
//		min = minutes;
//	}
//	void Time::getTime(int& hours, int& minutes)
//	{
//		hours = hr;
//		minutes = min;
//	}
//	void Time::printTime()
//	{
//		cout << hr << " : " << min;
//	}
//
//
//	Date::Date()
//	{
//		month = 1;
//		day = 1;
//		year = 2000;
//	}
//	Date::Date(int d, int m, int y)
//	{
//		day = d;
//		month = m;
//		year = y;
//	}
//	void Date::setDate(int d, int m, int y)
//	{
//		day = d;
//		month = m;
//		year = y;
//	}
//	void Date::getDate(int& d, int& m, int& y)
//	{
//		d = day;
//		m = month;
//		y = year;
//	}
//	void Date::printDate()
//	{
//		cout << endl << day << "/" << month << "/" << year << endl;
//	}
//
//	Event::Event()
//	{
//		eventDay.setDate(1,1,1900);
//		eventTime.setTime(0,0);
//		eventName = "Christmas";
//	}
//	Event::Event(int hours = 0, int minutes = 0, int m = 1, int d = 1, int y = 1900, string name = "Christmas")
//	{
//		eventDay.setDate(d, m, y);
//		eventTime.setTime(hours, minutes);
//		eventName = name;
//	}
//	void Event::setEventData(int hours, int minutes, int m, int d, int y, string name)
//	{
//		eventDay.setDate(d, m, y);
//		eventTime.setTime(hours, minutes);
//		eventName = name;
//	}
//	void Event::printEventData()
//	{
//		eventTime.printTime();
//		eventDay.printDate();
//		cout << eventName;
//	}
//
