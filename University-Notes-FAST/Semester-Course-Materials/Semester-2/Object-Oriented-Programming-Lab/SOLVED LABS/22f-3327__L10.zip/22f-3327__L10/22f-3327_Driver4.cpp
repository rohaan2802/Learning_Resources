//#include<iostream>
//#include"22f-3327_Interface4.h"
//using namespace std;
//
//int main()
//{
//	Event e1;
//	e1.setEventData(14, 30, 4, 5, 2023, "Meeting with boss");
//	cout << "Event details:\n";
//	e1.printEventData();
//	/*The first event e1 is created using the default constructor of the Event class,
//	which in turn calls the default constructors of the Date and Time classes to set the date
//	and time of the event to January 1st, 2000 at 12:00am, and sets the event name
//	to "Christmas" (as per the default parameter values in the constructor).
//	The setEventData method is then called to update the event details to a meeting with the
//	boss on May 4th, 2023 at 2:30pm.*/
//	Event e2(19, 0, 12, 24, 2023, "EID Party");
//	cout << "\n\n\nEvent details:\n";
//	e2.printEventData();
//	cout << endl;
//	/*The second event e2 is created using the constructor of the Event class that takes in initial values for the date, time, and event name.
//	The printEventData method is then called to print out the details of both events.*/
//
//}