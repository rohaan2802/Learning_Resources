//#include<string>
//using namespace std;
//class Time
//{
//public:
//	Time();
//	Time(int ,int);
//	void setTime(int , int );
//	void getTime(int&, int&);
//	void printTime();
//private:
//	int hr;
//	int min;
//};
//class Date
//{
//public:
//public:
//	Date();
//	Date(int, int, int);
//	void setDate(int, int, int);
//	void getDate(int&, int&, int&);
//	void printDate();
//private:
//	int month;
//	int day;
//	int year;
//};
//class Event
//{
//public:
//	Event();
//	Event(int , int , int ,int , int , string );
//	void setEventData(int hours, int minutes, int m, int d, int y, string name);
//	void printEventData();
//private:
//	string eventName;
//	Time eventTime;
//	Date eventDay;
//};
