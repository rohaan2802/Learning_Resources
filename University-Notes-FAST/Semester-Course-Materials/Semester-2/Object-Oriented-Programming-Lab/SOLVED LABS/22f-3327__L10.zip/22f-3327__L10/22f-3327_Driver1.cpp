//#include<iostream>
//#include"22f-3327_Interface1.h"
//using namespace std;
//int main()
//{
//	TA ta1(30);
//	// When TA object is made it inherits FACULTY and STUDENT . FACULTY and STUDENT further inherits PERSON .
//	//When Object is made PERSON constructor is called two times . once via Faculty and second time via Student 
//	// to finish this problem we use keyword "virtual" which will not make copies of PERSON in BOTH derived classes (FACULTY and STUDENT)
//	// As a result PERSON constructor is called once 
//}