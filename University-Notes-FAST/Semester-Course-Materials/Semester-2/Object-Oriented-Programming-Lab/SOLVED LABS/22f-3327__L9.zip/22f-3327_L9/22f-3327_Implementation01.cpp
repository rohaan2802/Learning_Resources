//#include<iostream>
//#include<string>
//#include"22f-3327_Interface_01.h"
//using namespace std;
//
//person::person()
//{
//	this->first_name = "Muhammad";
//	this->last_name = "Ali";
//	this->age = 18;
//}
//person::person(string FName, string LName, int age)
//{
//	this->first_name = FName;
//	this->last_name = LName;
//	this->age = age;
//}
//void person::setName()
//{
//	cout << "\nEnter First name :";
//	cin >> first_name;
//	cout << "\nEnter Last name :";
//	cin >> last_name;
//}
//void person::setAge()
//{
//	cout << "\nEnter Age:";
//	cin >> age;
//}
//void person::getName()
//{
//	cout << "\nFirst name :" << first_name << "\nLast Name :";
//	cout << last_name << "\nAge:";
//	cout << age;
//}
//void person::displayPerson()
//{
//	getName();
//}
//student::student() :person()
//{
//	cgpa = 0;
//}
//void student::setCGPA()
//{
//	cout << "\nEnter CGPA :";
//	cin >> cgpa;
//}
//void student::getCGPA()
//{
//	getName();
//	cout << "\nCGPA :" << cgpa << endl;
//}
//void student::displayStudent()
//{
//	displayPerson();
//	getCGPA();
//}
//
//underGraduate::underGraduate() :student()
//{
//	fyp_name = "N/A";
//}
//void underGraduate::setFypName()
//{
//	cout << "\nEnter FYP Name:";
//	cin >> fyp_name;
//}
//void underGraduate::getFYP()
//{
//	cout << "\n FYP Name:" << fyp_name;
//}
//void underGraduate::displayUnderGraduate()
//{
//	displayStudent();
//	getFYP();
//}
//
//graduate::graduate() :student()
//{
//	thesis_topic = "N/A";
//}
//void graduate::setThesisTopic()
//{
//	cin.clear();
//	cout << "\n Enter Thesis Topic :";
//	cin >> thesis_topic;
//}
//void graduate::getThesis()
//{
//	cout << "\n Thesis topic is: " << thesis_topic;
//}
//void graduate::displayGraduate()
//{
//	displayStudent();
//	getThesis();
//}
//
//faculty::faculty() :person()
//{
//	course_count = 0;
//	extension_number = 000;
//}
//void faculty::setCourseCount()
//{
//	cout << "\n Enter number of courses : ";
//	cin >> course_count;
//}
//void faculty::setextensionNumber()
//{
//	cout << "\n Enter telephone extension number :";
//	cin >> extension_number;
//}
//void faculty::getCourse_count()
//{
//	cout << "\n Number of courses currently teaching :" << course_count;
//}
//void faculty::getExtension_Number()
//{
//	cout << "\n Telephone Extension Number :" << extension_number;
//}
//void faculty::displayFaculty()
//{
//	displayPerson();
//	getCourse_count();
//	getExtension_Number();
//}
//
