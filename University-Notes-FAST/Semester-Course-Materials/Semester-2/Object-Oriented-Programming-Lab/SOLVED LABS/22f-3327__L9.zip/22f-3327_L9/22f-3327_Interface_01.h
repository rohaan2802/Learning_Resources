//using namespace std;
//class person
//{
//private:
//	string first_name;
//	string last_name;
//protected:
//	int age;
//public:
//	person();
//	person(string, string, int);
//	void setName();
//	void setAge();
//	void getName();
//	void displayPerson();
//
//};
//class student :public person
//{
//	float cgpa;
//public:
//	student();
//	void setCGPA();
//	void getCGPA();
//	void displayStudent();
//};
//class underGraduate : public student
//{
//	string fyp_name;
//public:
//	underGraduate();
//	void setFypName();
//	void getFYP();
//	void displayUnderGraduate();
//};
//class graduate :public student
//{
//	string thesis_topic;
//public:
//	graduate();
//	void setThesisTopic();
//	void getThesis();
//	void displayGraduate();
//};
//class faculty :public person
//{
//	int course_count;
//	int extension_number;
//public:
//	faculty();
//	void setCourseCount();
//	void setextensionNumber();
//	void getCourse_count();
//	void getExtension_Number();
//	void displayFaculty();
//};
