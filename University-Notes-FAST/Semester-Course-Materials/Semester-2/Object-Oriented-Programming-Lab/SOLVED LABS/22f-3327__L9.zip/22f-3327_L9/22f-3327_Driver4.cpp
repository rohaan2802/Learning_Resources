//#include"22f-3327_Interface_04.h"
//#include<iostream>
//using namespace std;
//
//int main() 
//{
//    // Create a BusinessMan object and call Employ and display functions
//    BusinessMan bm("John Smith", "123456");
//    cout << "\n Create an object of BusinessMan in main and call the Employ function.: \n";
//    bm.Employ();//� Create an object of BusinessMan in main and call the Employ function.
//    cout << "\nCall the display function of BusinessMan with the same object.:\n ";
//    bm.display();//Call the display function of BusinessMan with the same object. 
//
//    // Create an Unemployed object and print its status
//    cout << "\nCreate an object of UnEmployed in main and print the members:\n";
//    Unemployed um("Jane Doe");//Create an object of UnEmployed in main and print the members
//    um.getName();// because unemployed have access to only name of person class no other member inherited 
//
//    return 0;
//}