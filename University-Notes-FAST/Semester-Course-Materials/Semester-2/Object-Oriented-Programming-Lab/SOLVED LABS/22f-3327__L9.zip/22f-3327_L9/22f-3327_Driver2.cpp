//#include<iostream>
//#include "22f-3327_Interface_02.h"
//using namespace std;
//
//int main() 
//{
//    CustomerData customer;
//    // Input customer data
//    cout << "\n\t\t\tEnter Customer Data:\n\n";
//    customer.inputCustomerData();
//
//    // Display customer data
//    cout<<"\n\n\t\t\tCustomer Details :\n";
//    customer.displayCustomerData();
//    system("pause");
//    return 0;
//}
