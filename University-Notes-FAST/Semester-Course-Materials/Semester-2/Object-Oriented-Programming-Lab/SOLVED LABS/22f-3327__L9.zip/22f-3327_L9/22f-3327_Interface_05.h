#include<string>
using  namespace std;

class Vehicle 
{
private:
	float speed=0;
	float distance=0;
public:
	Vehicle();

	void setSpeed(float);
	void setDistance(float);
	float getSpeed();
	float getDistance();
	float computeDuration();
};

class WheelVehicle :public Vehicle
{
private :
	int wheels=0;
public: 
	void setWheels(int);
	int getWheels();
};

class WingVehicle :public Vehicle
{
private:
	int wings=0;
public :
	void setWings(int);
	int getWings();
};
class truck :public WheelVehicle
{
private: 
	float carryingLoad=0;
public:
	void setLoad(float);
	float getLoad();
};