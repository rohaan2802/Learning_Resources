//#include <string>
//using namespace std;
//class PersonData
//{
//
//private:
//    string firstName_;
//    string lastName_;
//    string address_;
//public:
//    // Constructor
//    PersonData();
//
//    // Getters
//    string getFirstName() const;
//    string getLastName() const;
//    string getAddress() const;
//
//    // Setters
//    void setFirstName(string firstName);
//    void setLastName(string lastName);
//    void setAddress(string address);
//};
//
//class CustomerData : public PersonData
//{
//private:
//    int customerNumber_;
//    bool mailingList_;
//public:
//    // Constructor
//    CustomerData();
//
//    // Getters
//    int getCustomerNumber() const;
//    bool getMailingList() const;
//
//    // Setters
//    void setCustomerNumber(int customerNumber);
//    void setMailingList(bool mailingList);
//
//    // Member functions
//    void inputCustomerData();
//    void displayCustomerData();
//};
//class PreferredCustomer : public CustomerData
//{
//private:
//    double purchasesAmount_;
//    double discountLevel_;
//public:
//    class PersonData 
//{
//
//private:
//    string firstName_;
//    string lastName_;
//    string address_;
//public:
//    // Constructor
//    PersonData();
//
//    // Getters
//    string getFirstName() const;
//    string getLastName() const;
//    string getAddress() const;
//
//    // Setters
//    void setFirstName( string firstName);
//    void setLastName( string lastName);
//    void setAddress( string address);
//};
//
//class CustomerData : public PersonData
//{
//private:
//    int customerNumber_;
//    bool mailingList_;
//public:
//    // Constructor
//    CustomerData();
//
//    // Getters
//    int getCustomerNumber() const;
//    bool getMailingList() const;
//
//    // Setters
//    void setCustomerNumber(int customerNumber);
//    void setMailingList(bool mailingList);
//
//    // Member functions
//    void inputCustomerData();
//    void displayCustomerData();
//};
//
//
//    PreferredCustomer();
//    PreferredCustomer(string firstName, string lastName, string address, int customerNumber, bool mailingList, double purchasesAmount);
//    double getPurchasesAmount();
//    void setPurchasesAmount(double purchasesAmount);
//
//    double getDiscountLevel() const;
//    void setDiscountLevel(double discountLevel);
//
//    void calculateDiscount();
//
//    void inputPreferredCustomerData();
//    void displayPreferredCustomerData();
//};
//
//
