#include<iostream>
using namespace std;
#include"22f-3327_Interface_05.h"

	Vehicle::Vehicle() :speed(0), distance(0) {}

	void Vehicle::setSpeed(float speed)
	{
		this->speed = speed;
	}
	void Vehicle::setDistance(float distance)
	{
		this->distance = distance;
	}
	float Vehicle::getSpeed()
	{
		return this->speed;
	}
	float Vehicle::getDistance()
	{
		return this->distance;
	}
	float Vehicle::computeDuration()
	{
		return(distance /speed);
	}


	
	void WheelVehicle::setWheels(int wheels)
	{
		this->wheels = wheels;
	}
	int WheelVehicle::getWheels()
	{
		return this->wheels;
	}

	void WingVehicle::setWings(int wings)
	{
		this->wings = wings;
	}
	int WingVehicle::getWings()
	{
		return this->wings;
	}


	void truck::setLoad(float load)
	{
		this->carryingLoad = load;
	}
	float truck::getLoad()
	{
		return carryingLoad;
	}
