//#include<iostream>
//#include"22f-3327_Interface_01.h"
//using namespace std;
//
//int main()
//{
//	cout << "Enter Under-Graduate student DATA:\n";
//	underGraduate st2;
//	st2.setName();
//	st2.setAge();
//	st2.setCGPA();
//	st2.setFypName();
//	cout << "\nEnter graduate student DATA:\n";
//	graduate st1;
//	st1.setName();
//	st1.setAge();
//	st1.setCGPA();
//	st1.setThesisTopic();
//	cout << "\nEnter FACULTY DATA:\n";
//	faculty teacher1;
//	teacher1.setName();
//	teacher1.setAge();
//	teacher1.setextensionNumber();
//	teacher1.setCourseCount();
//
//	cout << "\n -------------------------OUTPUT----------------------------";
//	cout << "\n -------------------------UNDERGRADUATE---------------------";
//	st2.displayUnderGraduate();
//	cout << "\n ----------------------------GRADUATE-----------------------";
//	st1.displayGraduate();
//	cout << "\n -------------------------FACULTY---------------------";
//	teacher1.displayFaculty();
//	system("pause");
//	return 0;
//}