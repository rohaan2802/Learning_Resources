//#include "22f-3327_Interface_03.h"
//#include <iostream>
//#include<string>
//using namespace std;
//
//// Constructor
//PersonData::PersonData() {}
//
//// Getters
//string PersonData::getFirstName() const
//{
//    return firstName_;
//}
//
//string PersonData::getLastName() const
//{
//    return lastName_;
//}
//
//string PersonData::getAddress() const
//{
//    return address_;
//}
//
//// Setters
//void PersonData::setFirstName(string firstName)
//{
//    this->firstName_ = firstName;
//}
//
//void PersonData::setLastName(string lastName)
//{
//    this->lastName_ = lastName;
//}
//
//void PersonData::setAddress(string address)
//{
//    this->address_ = address;
//}
//
//// Constructor
//CustomerData::CustomerData() :PersonData() {}
//
//// Getters
//int CustomerData::getCustomerNumber() const
//{
//    return customerNumber_;
//}
//
//bool CustomerData::getMailingList() const
//{
//    return mailingList_;
//}
//
//// Setters
//void CustomerData::setCustomerNumber(int customerNumber)
//{
//    customerNumber_ = customerNumber;
//}
//
//void CustomerData::setMailingList(bool mailingList)
//{
//    mailingList_ = mailingList;
//}
//// Member functions
//void CustomerData::inputCustomerData()
//{
//    string firstName, lastName, address;
//    int customerNumber;
//    bool mailingList;
//
//    // Input personal data
//    cout << "Enter first name: ";
//    getline(cin, firstName);
//    setFirstName(firstName);
//
//    cout << "Enter last name: ";
//    getline(cin, lastName);
//    setLastName(lastName);
//
//    cout << "Enter address: ";
//    getline(cin, address);
//    setAddress(address);
//
//    // Input customer data
//    cout << "Enter customer number: ";
//    cin >> customerNumber;
//    setCustomerNumber(customerNumber);
//
//    cout << "Do you want to be on the mailing list? (0 for No / 1 for yes) : ";
//    cin >> mailingList;
//    setMailingList(mailingList);
//}
//
//void CustomerData::displayCustomerData()
//{
//    cout << "First name: " << getFirstName() << endl;
//    cout << "Last name: " << getLastName() << endl;
//    cout << "Address: " << getAddress() << endl;
//    cout << "Customer number: " << getCustomerNumber() << endl;
//    cout << "Mailing list: " << (getMailingList() ? "Yes" : "No") << endl;
//}
//// Constructor
//PreferredCustomer::PreferredCustomer() : purchasesAmount_(0), discountLevel_(0) {}
//
//PreferredCustomer::PreferredCustomer(string firstName, string lastName, string address, int customerNumber, bool mailingList, double purchasesAmount) 
//{
//    this->purchasesAmount_ = purchasesAmount;
//    this->discountLevel_ = 0.0;
//}
//
//double PreferredCustomer::getPurchasesAmount()  
//{
//    return purchasesAmount_;
//}
//
//void PreferredCustomer::setPurchasesAmount(double purchasesAmount)
//{
//    this->purchasesAmount_ = purchasesAmount;
//    calculateDiscount();// sets discount level 
//}
//
//double PreferredCustomer::getDiscountLevel() const
//{
//    return discountLevel_;
//}
//
//void PreferredCustomer::setDiscountLevel(double discountLevel)
//{
//    discountLevel_ = discountLevel;
//}
//
//void PreferredCustomer::calculateDiscount()
//{
//    if (purchasesAmount_ >= 2000) {
//        discountLevel_ = 0.1;
//    }
//    else if (purchasesAmount_ >= 1500) {
//        discountLevel_ = 0.07;
//    }
//    else if (purchasesAmount_ >= 1000) {
//        discountLevel_ = 0.06;
//    }
//    else if (purchasesAmount_ >= 500) {
//        discountLevel_ = 0.05;
//    }
//    else {
//        discountLevel_ = 0;
//    }
//}
//
//void PreferredCustomer::inputPreferredCustomerData() 
//{
//    inputCustomerData();
//    cout << "Enter purchases amount: ";
//    cin >> purchasesAmount_;
//    calculateDiscount();
//}
//
//void PreferredCustomer::displayPreferredCustomerData() 
//{
//    displayCustomerData();
//    cout << "Purchases amount: $" << getPurchasesAmount() << "\n";
//    cout << "Discount level: " << getDiscountLevel() * 100 << "%\n";
//}
