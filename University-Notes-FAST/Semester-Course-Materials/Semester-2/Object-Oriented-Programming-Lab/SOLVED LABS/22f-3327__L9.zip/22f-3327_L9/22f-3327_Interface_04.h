//#include <string>
//using namespace std;
//class Person 
//{
//private:
//    int age;
//    char gender;
//
//public:
//    string name;
//    Person();
//    Person(const string& name, int age, char gender);
//    virtual ~Person();
//
//    const string& getName() const;
//    int getAge() const;
//    char getGender() const;
//};
//
//class EmployedPerson : public Person 
//{
//public:
//    string NIC;
//    EmployedPerson(const string& name, const string&NIC);
//    virtual ~EmployedPerson();
//
//    const string& getNIC() const;
//    virtual void Employ() const;
//};
//
//class Unemployed : public Person
//{
//public:
//    Unemployed(const string& name);
//    virtual ~Unemployed();
//};
//
//class BusinessMan : public EmployedPerson 
//{
//public:
//    BusinessMan(const string& name, const string&NIC);
//    virtual ~BusinessMan();
//
//    void display() const;
//};