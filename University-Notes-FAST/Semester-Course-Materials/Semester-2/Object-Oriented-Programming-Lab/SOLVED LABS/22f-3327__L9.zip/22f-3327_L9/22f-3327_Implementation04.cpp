//#include"22f-3327_Interface_04.h"
//#include<iostream>
//using namespace std;
//
//Person::Person() : name(""), age(0), gender(' ') {}
//
//Person::Person(const string& name=" ", int age=0, char gender=' ')
//    : name(name), age(age), gender(gender) {}
//
//Person::~Person() {}
//
//const string& Person::getName() const {
//    return name;
//}
//
//int Person::getAge() const {
//    return age;
//}
//
//char Person::getGender() const {
//    return gender;
//}
//EmployedPerson::EmployedPerson(const string& name=" ", const string& NIC=" ")
//    : Person(name, 0, ' '), NIC(NIC) {}
//
//EmployedPerson::~EmployedPerson() {}
//const string& EmployedPerson::getNIC() const {
//    return NIC;
//}
//void EmployedPerson::Employ() const 
//{
//    cout << "Hi, I am Employ from Employed Class" << endl;
//}
//
//
//Unemployed::Unemployed(const string& name) : Person(name, 0, ' ') 
//{
//    cout << "\nHi, I am UnEmploy from UnEmployed Class\n";
//}
//Unemployed::~Unemployed() {}
//
//
//
//BusinessMan::BusinessMan(const string& name, const string& NIC)  : EmployedPerson(name, NIC) {}
//
//BusinessMan::~BusinessMan() {}
//
//void BusinessMan::display() const 
//{
//    cout << "Name: " << getName() << endl;
//    cout << "NIC: " << getNIC() << endl;
//}