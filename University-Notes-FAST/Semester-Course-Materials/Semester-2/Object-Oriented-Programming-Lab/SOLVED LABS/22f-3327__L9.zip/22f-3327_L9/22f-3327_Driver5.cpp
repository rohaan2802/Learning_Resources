#include <iostream>
#include"22f-3327_Interface_05.h"
using namespace std;
// main function
int main() {
	int choice = 0;
	int temp1 = 0;
	float temp = 0;
	WingVehicle obj;
	truck obj1;
	cout << "======================================\n";
	cout << "               MENU\n";
	cout << "--------------------------------------\n";
	cout << "1. Enter DATA for Wing Vehicle.\n";
	cout << "2. Enter DATA for truck.\n";
	cout << "3. Terminate the Program\n";
	cout << "======================================\n";
	while (choice != 3) 
	{
		cout << "Enter Choice: ";
		cin >> choice;
		cout << "======================================\n";
		switch (choice) 
		{
		case 1:
			cout << "Enter Wings: ";
			cin >> temp;
			obj.setWings(temp1);
			cout << "Enter Speed: ";
			cin >> temp;
			obj.setSpeed(temp);
			cout << "Enter Distance: ";
			cin >> temp;
			obj.setDistance(temp);
			cout << "--------------------------\n";
			cout << "          OUTPUT \n";
			cout << "--------------------------\n";
			cout << "Duration is : " << obj.computeDuration() << endl;
			break;
		case 2:
			cout << "Enter Carring Load: ";
			cin >> temp;
			obj1.setLoad(temp);
			cout << "Enter Wheels: ";
			cin >> temp;
			obj1.setWheels(temp1);
			cout << "Enter Speed: ";
			cin >> temp;
			obj1.setSpeed(temp);
			cout << "Enter Distance: ";
			cin >> temp;
			obj1.setDistance(temp);
			cout << "--------------------------\n";
			cout << "          OUTPUT \n";
			cout << "--------------------------\n";
			cout << "Duration is : " << obj1.computeDuration() <<
				endl;
			break;
		case 3:
			break;
		default:
			cout << "INVALID INPUT\n";
			break;
		}
		cout << "======================================\n";
	}
	// /// /// /// //// /// 
	system("pause");
	return 0;
}