//#include<string>
//using namespace std;
//class PersonData 
//{
//
//private:
//    string firstName_;
//    string lastName_;
//    string address_;
//public:
//    // Constructor
//    PersonData();
//
//    // Getters
//    string getFirstName() const;
//    string getLastName() const;
//    string getAddress() const;
//
//    // Setters
//    void setFirstName( string firstName);
//    void setLastName( string lastName);
//    void setAddress( string address);
//};
//
//class CustomerData : public PersonData
//{
//private:
//    int customerNumber_;
//    bool mailingList_;
//public:
//    // Constructor
//    CustomerData();
//
//    // Getters
//    int getCustomerNumber() const;
//    bool getMailingList() const;
//
//    // Setters
//    void setCustomerNumber(int customerNumber);
//    void setMailingList(bool mailingList);
//
//    // Member functions
//    void inputCustomerData();
//    void displayCustomerData();
//};
//
