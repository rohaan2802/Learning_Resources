//#include<iostream>
//#include"22f-3327_Interface_03.h"
//#include"22f-3327_Interface_02.h"
//using namespace std;
//int main()
//{
//	PreferredCustomer customer1;
//	cout << "\n\t\t\t Preferred customer Data:\n";
//	customer1.inputPreferredCustomerData();
//	cout << "\n\n\t\t\t OUTPUT \n";
//	customer1.displayPreferredCustomerData();
//	system("pause");
//	return 0;
//
//}