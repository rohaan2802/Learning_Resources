//#include <iostream>
//#include <string>
//
//using namespace std;
//class Character;
//class Warrior;
//class Mage;
//class Character
//{
//protected:
//    string name;
//    int level;
//    int health;
//
//public:
//    Character( string Name=" ", int Level=0, int Health=100) : name(Name), level(Level), health(Health) {}
//
//    void displayDetails()
//    {
//        cout << "Name: " << name << endl;
//        cout << "Level: " << level << endl;
//        cout << "Health: " << health << endl;
//    }
//
//    void updateHealth(int newHealth)
//    {
//        health = newHealth;
//    }
//
//    friend class Warrior;
//    friend class Mage;
//};
//
//class Warrior 
//{
//protected:
//    Character character;
//    string weapon;
//    int strength;
//
//public:
//    Warrior( string Name=" ", int Level=0, int Health=100, string Weapon=" ", int Strength=10) : character(Name, Level, Health), weapon(Weapon), strength(Strength) {}
//
//    void displayDetailsWarrior()
//    {
//        character.displayDetails(); // Call displayDetails() of the parent class (Character)
//        cout << "Weapon: " << weapon << endl;
//        cout << "Strength: " << strength << endl;
//    }
//
//    void attack()
//    {
//        cout << "Warrior " << character.name << " attacks with " << weapon << endl;
//        cout << "Warrior has  strength " << strength << endl;
//    }
//    /*void foo(int var) {
//        character.level = var;
//    }*/
// 
//};
//
//class Mage 
//{
//protected:
//    Character character;
//    string spell;
//    int intelligence;
//
//public:
//    Mage( string Name="", int Level=0, int Health=100, string Spell=" ", int Intelligence=100): character(Name, Level, Health), spell(Spell), intelligence(Intelligence) {}
//    
//    void displayDetailsMage()
//    {
//        character.displayDetails(); // Call displayDetails() of the parent class (Character)
//        cout << "Spell: " << spell << endl;
//        cout << "Intelligence: " << intelligence << endl;
//    }
//
//    void castSpell()
//    {
//        cout << "Mage " << character.name << " casts spell " << spell << endl;
//        cout<<" Mage has intelligence " << intelligence << endl;
//    }
//};
//
//int main()
//{
//    cout << "Death slayer has appeared to destroy EARTH with health of 230hp. \n Available saviours:\n";
//    Character character("Ali", 4, 100);
//    character.displayDetails();
//    cout << endl;
//
//   
//    Warrior warrior("Taha", 2, 150, "MK14", 50);
//    warrior.displayDetailsWarrior();
//    //warrior.foo(10);
//    warrior.attack();
//    cout << "taha has dealt damage of 110 \n\n";
//    cout << endl;
//
//
//    Mage mage("Sameed", 3, 120, "Abra ka Dabra ", 70);
//    mage.displayDetailsMage();
//    mage.castSpell();
//    cout << "Sameed has dealt damage of 120 ";
//    cout << endl;
//    // Update health of a Character
//    cout << "\n Ali takes health potion.\n";
//    character.updateHealth(80);
//    character.displayDetails();
//
//    cout << "\n Death slayer defeated.";
//    cout << "\n You WONNNNNN!!!!!!!!!!";
//    return 0;
//}
