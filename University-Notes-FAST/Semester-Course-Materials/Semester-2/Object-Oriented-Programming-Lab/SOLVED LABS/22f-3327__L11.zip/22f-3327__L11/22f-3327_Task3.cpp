#include<iostream>
using namespace std;
class factorial 
{
public:
	int n;
	long fact;
	factorial(int num=1,long factorial=1):n(num),fact(factorial) {}
	void setNum(int num)
	{
		n = num;
	}
	long getFact()
	{
		return fact;
	}
	long operator !()
	{
		fact=1;
		if (n == 0)
			fact=1;
		else 
		{
			while (n > 0)
			{
				fact *= n;
				n -= 1;
			}
		}
		return fact;
	}
	//friend ostream &operator <<(ostream& obj, factorial f);
};
//ostream &operator <<(ostream& obj, factorial f)
//{
//	obj << f.n;
//	return obj;
// }

//istream &operator >>(istream& obj, factorial &f)
//{
//	obj >> f.n;
//	return obj;
//}
int main()
{
	factorial num1;
	int temp;
	cout << "Enter a number :";
	cin >> temp;
	num1.setNum(temp);
	
	cout << "\n Factorial of " << temp << " is " << !num1;
	//num1.getFact() ;
}