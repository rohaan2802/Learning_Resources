//#include <iostream>
//#include <string>
//
//using namespace std;
//
//class MultimediaItem
//{
//private:
//    string title;
//    string creator;
//    int publicationYear;
//public:
//    MultimediaItem(string t="", string c="", int y=2000)
//    {
//        title = t;
//        creator = c;
//        publicationYear = y;
//    }
//    //getter functions
//    string getTitle()
//    {
//        return title;
//    }
//    string getCreator()
//    {
//        return creator;
//    }
//    int getPublicationYear()
//    {
//        return publicationYear;
//    }
//};
//
//// Derived class Book, inherits from MultimediaItem
//class Book : public MultimediaItem
//{
//private:
//    string author;
//    string genre;
//    int numPages;
//public:
//    Book(string t="", string c = "", int y=2000, string a = "", string g = "", int n=500) : MultimediaItem(t, c, y)
//    {
//        author = a;
//        genre = g;
//        numPages = n;
//    }
//
//    friend void displayDetails(Book book); // Friend function to display details of Book
//};
//
//
//class Video : public MultimediaItem
//{
//private:
//    int duration;
//    string format;
//    string resolution;
//public:
//    Video(string t, string c, int y, int d, string f, string r) : MultimediaItem(t, c, y)
//    {
//        duration = d;
//        format = f;
//        resolution = r;
//    }
//
//    friend void displayDetails(Video video); // Friend function to display details of Video
//};
//
//
//class MusicAlbum : public MultimediaItem
//{
//private:
//    string artist;
//    string genre;
//    int numTracks;
//public:
//    MusicAlbum(string t, string c, int y, string ar, string g, int n) : MultimediaItem(t, c, y)
//    {
//        artist = ar;
//        genre = g;
//        numTracks = n;
//    }
//
//    friend void displayDetails(MusicAlbum album); // Friend function to display details of MusicAlbum
//};
//
//// Friend function to display details of Book
//void displayDetails(Book book)
//{
//    cout << "Title: " << book.getTitle() << endl;
//    cout << "Creator: " << book.getCreator() << endl;
//    cout << "Publication Year: " << book.getPublicationYear() << endl;
//    cout << "Author: " << book.author << endl;
//    cout << "Genre: " << book.genre << endl;
//    cout << "Number of Pages: " << book.numPages << endl;
//}
//
//// Friend function to display details of Video
//void displayDetails(Video video)
//{
//    cout << "Title: " << video.getTitle() << endl;
//    cout << "Creator: " << video.getCreator() << endl;
//    cout << "Publication Year: " << video.getPublicationYear() << endl;
//    cout << "Duration: " << video.duration << endl;
//    cout << "Format: " << video.format << endl;
//    cout << "Resolution: " << video.resolution << endl;
//}
//
//// Friend function to display details of MusicAlbum
//void displayDetails(MusicAlbum album)
//{
//    cout << "Title: " << album.getTitle() << endl;
//    cout << "Creator: " << album.getCreator() << endl;
//    cout << "Publication Year: " << album.getPublicationYear() << endl;
//    cout << "Artist: " << album.artist << endl;
//    cout << "Genre: " << album.genre << endl;
//    cout << "Number of Tracks: " << album.numTracks << endl;
//}
//int main()
//{
//    // Create a Book object
//    Book book("Percy Jackson", "JOhn Rocco", 1925, "Rick Riordan", "Fantasy", 381);
//
//    // Create a Video object
//    Video video("InterStellar", "Christopher Nolan", 2014, 169, "Blu-ray", "1080p");
//
//    // Create a MusicAlbum object
//    MusicAlbum album("Off the Wall", "Michael Jackson", 1979, "Michael Jackson", "Rock", 8);
//
//    // Call the friend functions to display details of the objects
//    cout << "Book Details:" << endl;
//    displayDetails(book);
//
//    cout << "\n-----------------------------------" << endl;
//
//
//
//    cout << "Video Details:" << endl;
//    displayDetails(video);
//    cout << "\n-----------------------------------" << endl;
//
//    cout << "Music Album Details:" << endl;
//    displayDetails(album);
//    cout << "\n-----------------------------------" << endl;
//
//    return 0;
//}
