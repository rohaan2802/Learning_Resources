//this program saves the acoount details of a user . user can with draw,deposit and sidplay information of account 
#include<iostream>
using namespace std;
class Account
{
private:
	double balance;
	double interestRate;
	double interest;
	int transactions;
	int time = 12;// time period for interest is 12 months 
	int count;
public:
	Account()// default constructor 
	{
		balance = 0;
		interestRate = 4.5;
		interest = 0;
		transactions = 0;
		count = 0;
	}
	Account(double Bal, double intRate)// parametrized constructor 
	{
		balance = Bal;
		interestRate = intRate;
		interest = 0;
		transactions = 0;
		count = 0;
	}
	void setInterestRate(double intRate)//to change interest rate 
	{
		interestRate = intRate;
	}
	void makeDeposit(double deposit)// deposit money into account  and added into account 
	{
		balance += deposit;
	}
	void withDraw(double amount)// withdraw money from account and subtracted from balance 
	{
		if (balance >= amount)// if withdrawal amount greater than balance 
			balance -= amount;
		else
			cout << "\nWithdrawal amount is greater than balnce in account.Check your balance and try again .";
	}
	void calcInnterest()// calculate interest and add in balance 
	{
		interest = (interestRate * balance * time)/100;
		balance += interest;
		cout << "\n Interest is Rs." << interest;
		cout << "\n Balance after interest :Rs." << balance;
	}
	void incCount()// increment count for every choice 
	{
		++count;
	}
	void incTransactions() // increment transactions number
	{
		++transactions;
	}
	int getCount()// show the number of choices made 
	{
		return count;
	}
	double getInterestRate()// display interest rate
	{
		return interestRate;
	}
	double getBalance()// display balance 
	{
		return balance;
	}
	double getInterest()// display interest 
	{
		return interest;
	}
	int getTransactions()// display number of transctions made 
	{
		return transactions;
	}
	~Account()//destructor 
	{
		cout << "\nDestructor is called .";
	}
};

// main function 
int main()
{
	Account person1(0,5);// first parameter is balance and second is interest rate 
	int choice = 0;
	do
	{
		cout << "\n------------------------------MENU------------------------------\n";
		cout << "1. Make a deposit.\n";
		cout << "2. Make a withdrawal.\n";
		cout << "3. Change Interest Rate.\n";
		cout << "4. Calculate interest for 1 year time period.\n";
		cout << "5. Display the Interest Rate.\n";
		cout << "6. Display the Account Balance.\n";
		cout << "7. Display interest earned for this period.\n";
		cout << "8. Display the Number of transactions.\n";
		cout << "9. Display the Number of choices made.\n";
		cout << "10. Exit the Program.\n";
		cout << "------------------------------------------------------------------";
		cout << "\nEnter choice: ";
		cin >> choice;
		while (choice < 1 || choice>10)
		{
			cout << "\nInvalid Input . Enter again:";
			cin >> choice;
		}
		if (choice > 0 && choice < 10)
		{
			person1.incCount();
		}
		double amount=0;
		double intRate = 0;
		switch (choice)
		{
		case 1:
			cout << "------------------------------------------------------------------";
			cout << "\nDeposit Amount :Rs.";
			cin >> amount;
			person1.makeDeposit(amount);
			person1.incTransactions();
			cout << "\nTransacton of "<<amount <<" is Successful";
			break;
		case 2:
			cout << "------------------------------------------------------------------";
			cout << "\n Withdrawal Amount :Rs.";
			cin >> amount;
			person1.withDraw(amount);
			person1.incTransactions();
			break;
		case 3:
			cout << "------------------------------------------------------------------";
			cout << "\nEnter new interest rate :";
			cin >> intRate;
			person1.setInterestRate(intRate);
			break;
		case 4:
			cout << "------------------------------------------------------------------";
			person1.calcInnterest();
			break;
		case 5:
			cout << "------------------------------------------------------------------";
			cout << "\nInterest rate is :" << person1.getInterestRate();
			break;
		case 6:
			cout << "------------------------------------------------------------------";
			cout << "\nCurrent balance is :Rs." << person1.getBalance();
			break;
		case 7:
			cout << "------------------------------------------------------------------";
			cout << "\nInterest is :Rs." << person1.getInterest();
			break;
		case 8:
			cout << "------------------------------------------------------------------";
			cout << "\nNumber of Transactions is :" << person1.getTransactions();
			break;
		case 9: 
			cout << "------------------------------------------------------------------";
			cout << "\n Number of Choices made are : " << person1.getCount();
			break;
		case 10:
			cout << "------------------------------------------------------------------";
			cout << "\n Thanks for using Home Software Company program. ";
			break;
		}
	}while (choice != 10);
	system("pause");
	return 0;
}