//#include <iostream>
//using namespace std;
// 
//class Area 
//{
//private:
//	int length;
//	int width;
//	int area;
//	static int counter;// static variable 
//public:
//	Area() : area(0), length(0), width(0) {};// default constructor 
//	Area(int length, int width)	// overloaded constructor 
//	{
//		this->length = length;
//		this->width = width;
//		this->area = length * width;
//	}
//	static int count();
//	void display() 
//	{
//		cout << "            OutPut\n";
//		cout << " Area is  : " << area << endl;
//		cout << " Number of Count is : " << count() << endl;
//	}
//};
//int Area::counter;// static variable initialized with 0
//int Area::count()//static function
//{
//	counter++;
//	return counter;
//}
//void input(int &length, int &width)// by reference parameters passed for input 
//{
//	cout << "\n\n           Input\n";
//	cout << "Enter length: ";
//	cin >> length;
//	cout << "Enter Width: ";
//	cin >> width;
//}
//
//int main() {
//	int length = 0, width = 0;
//	input(length, width);
//	Area area01(length, width);
//	area01.display();
//	input(length, width);
//	Area area02(length, width);
//	area02.display();
//	input(length, width);
//	Area area03(length, width);
//	area03.display();
//	system("pause");
//	return 0;
//}
//
//
