//#include <iostream>
//using namespace std;
//// class of matrix 
//class Matrix 
//{
//private:
//	int row;
//	int col;
//	double** array;
//public:
//	// default constructor 
//	Matrix()
//	{
//		row = 2;
//		col = 3;
//		array = new double* [row];
//		for (int i = 0; i < row; i++)
//		{
//			array[i] = new double[col];
//		}
//		// initialize the all matrix entries with 1
//		for (int i = 0; i < row; i++) 
//		{
//			for (int j = 0; j < col; j++) 
//			{
//				array[i][j] = 1;
//			}
//		}
//		cout << "\n Default construcor called ";
//	}
//	// overloaded CONSTRUCTOR 
//	Matrix(int row, int col) 
//	{
//		this->row = row;
//		this->col = col;
//		array = new double* [row];
//		for (int i = 0; i < row; i++) 
//		{
//			array[i] = new double[col];
//		}
//		cout << "\n Overloaded construcor called \n";
//	}
//	// copy constructor
//	Matrix(const Matrix& matrix)
//	{
//		this->row = 2;
//		this->col = 3;
//		this->array = matrix.array;
//		cout << "\n Copy construcor called \n";
//	}
//	// input data function
//	void inputDataMatrix()
//	{
//		for (int i = 0; i < row; i++)
//		{
//			for (int j = 0; j < col; j++) 
//			{
//				cout << "\nEnter input of ( " << i << "," << j << " ) : ";
//				cin >> array[i][j];
//			}
//		}
//	}
//	// Add Matrix 
//	Matrix addMatrix(Matrix matrix2) 
//	{
//		for (int i = 0; i < row; i++) 
//		{
//			for (int j = 0; j < col; j++) 
//			{
//				array[i][j] = matrix2.array[i][j] + array[i][j];
//			}
//		}
//		return *this;
//	}
//	// display function
//	void display()
//	{
//		cout << "   MATRIX DISPLAY \n";
//		for (int i = 0; i < 2; i++) 
//		{
//			for (int j = 0; j < 3; j++) 
//			{
//				cout << array[i][j] << "   ";
//			}
//			cout << endl;
//		}
//	}
//	// Destructor 
//	~Matrix()
//	{
//
//		cout << "\n Destructor called ";
//	}
//};
//// main function 
//int main() 
//{
//	//Create a dynamic array of matrix of size 4.
//	Matrix* matrix_[4];
//	//Assign memory at 1st index with overloaded constructor of same size
//	matrix_[0] = new Matrix();
//	matrix_[1] = new Matrix(2, 3);
//	matrix_[1]->inputDataMatrix();
//	matrix_[2] = new Matrix;
//	//Save result matrix at 3rd index of add matrix 
//	*matrix_[2] = matrix_[0]->addMatrix(*matrix_[1]);
//	// Call copy constructor which will copy matrix[3] =matrix[2];
//	 matrix_[3]=new Matrix(*matrix_[2]);
//	// display the matrix
//	cout << "\nMatrix 1 :\n";
//	matrix_[1]->display();
//	cout << "\nMatrix 2 :\n";
//	matrix_[2]->display();
//	cout << "\nMatrix 3 :\n";
//	matrix_[3]->display();
//
//	matrix_[0]->~Matrix();
//	matrix_[1]->~Matrix();
//	matrix_[2]->~Matrix();
//	matrix_[3]->~Matrix();
//	// de allocation of main memory
//	/*for (int i = 0; i < 4; i++) {
//		delete[i] matrix_;
//	}*/
//	//*matrix_ = 0;
//	//free(matrix_);
//	
//
//	
//	system("pause");
//	return 0;
//}
