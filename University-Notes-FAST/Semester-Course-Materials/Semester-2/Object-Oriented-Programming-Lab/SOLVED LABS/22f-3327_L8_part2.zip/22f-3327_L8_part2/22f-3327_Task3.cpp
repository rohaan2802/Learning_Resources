#include <iostream>
using namespace std;

class TicTacToe 
{
private:
    int board[3][3];// 2d array of board 
    int currentPlayer;// player wither 1 or 2 

public:
    TicTacToe() // default constructor 
    {
        for (int i = 0; i < 3; i++)// initializes all entries of board to 0
        {
            for (int j = 0; j < 3; j++) 
            {
                board[i][j] = 0;
            }
        }
        currentPlayer = 1;// by default it is first player turn 
    }

    void printBoard()// to print board 
    {
        cout << endl << "-------------" << endl;
        for (int i = 0; i < 3; i++)
        {
            cout << "| ";
            for (int j = 0; j < 3; j++)
            {
                cout << board[i][j] << " | ";
            }
            cout << endl << "-------------" << endl;
        }
    }

    bool makeMove(int row, int col) // enter entry in board according to user 
    {
        if (board[row-1][col-1] == 0)// if entry is zero or unoccupied then only replace 0 with 1/2 otherwise ask again 
        {
            board[row-1][col-1] = currentPlayer;// replace 0 with 1/2
            if (checkWin()) // win condition prompt message 
            {
                cout << "Player " << currentPlayer << " wins!" << endl;
                return true;
            }
            else if (checkDraw())// draw message prompt message 
            {
                cout << "Game is a draw!" << endl;
                return true;
            }
            else // if neither win nor draw then next player turn
            {
                if (currentPlayer == 1)
                    currentPlayer = 2;
                else 
                    currentPlayer = 1;
                return false;
            }
        }
        else// if box already occupied then 
        {
            cout << "\n Already marked .Choose another box .\n";
            return false;
        }
    }

    bool checkWin() 
    {
        // Check rows
        for (int i = 0; i < 3; i++) 
        {
            if (board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) 
            {
                return true;
            }
        }

        // Check columns
        for (int i = 0; i < 3; i++)
        {
            if (board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0)
            {
                return true;
            }
        }

        // Check diagonals
        if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] != 0) 
        {
            return true;
        }
        if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[0][2] != 0) {
            return true;
        }

        return false;
    }

    bool checkDraw()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (board[i][j] == 0) 
                {
                    return false;
                }
            }
        }
        return true;
    }
    int getCurrentPlayer()// to display which player turn now 
    {
        return currentPlayer;
    }
};

int main() 
{
    TicTacToe game;
    int row, col;

    while (true)
    {
        game.printBoard();// print board
        cout << "Player " << game.getCurrentPlayer() << ", enter row and column . e.g(1 3): ";// prompt user to enter 
        cin >> row >> col;
        if (game.makeMove(row, col)) // loop will only terminate when either user wins or draw . when user wins, if condition is true and control enter body of condition and then loop is exit by break statement  
        {
            game.printBoard();
            break;
        }
    }
    system("pause");
    return 0;
}
