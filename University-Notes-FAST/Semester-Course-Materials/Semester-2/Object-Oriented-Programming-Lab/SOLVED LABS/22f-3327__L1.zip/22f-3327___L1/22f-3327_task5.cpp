// reverse a string using pointer 
#include <iostream>
using namespace std;

int main() {
	// input the string
	char str[100];
	cout << "Enter the string: ";
	cin >> str;
	// reverse the string uisng pointer
	char* first = str;
	char* last = str + strlen(str) - 1;
	int length = (strlen(str) / 2);
	for (int i = 0; i < length; i++)
	{
		*first = str[i];
		*last = str[strlen(str) - 1 - i];
		str[i] = *last;
		str[strlen(str) - 1 - i] = *first;
	}
	// printing the reversed string
	string result = str;
	cout << "Reverse of string is: " << result << endl;
	system("pause");
	return 0;
}
// tried but couldn't figure it out 
