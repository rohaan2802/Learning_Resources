///* this program reads data from a text file and store it in an array 
//then by linear search it find maximum and minimum number alongwith their indexes*/
//#include<iostream>
//#include<fstream>
//using namespace std;
//void linearSearch(int arr[]);
//const int Size = 10;
//
//int main()
//{
//	int readData[Size];
//	ifstream fin;
//	// data is being read and stored in readData array
//
//	fin.open("num.txt");
//	if (!(fin.is_open()))
//	{
//		cout << "\n File cannot be opened .";
//		return 99;
//	}
//	while (!fin.eof())
//	{
//		for (int i = 0; i < Size; ++i)
//		{
//			fin >> readData[i];
//		}
//	}
//	cout << "\n The array is \n";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << readData[i] << "  ";
//	}
//	linearSearch(readData);
//	cout << endl;
//	system("pause");
//	return 0;
//}
//// searching an array by linear search method . traversing whole array and finding minimum and maximum number alongwith their indexes
//void linearSearch(int arr[])
//{
//	int min = arr[0], max = arr[0], minIndex = 0, maxIndex = 0;
//	// minimum number and its index using linear search
//	for (int a = 0; a < Size; ++a)
//	{
//		if (arr[a] < arr[minIndex])
//		{
//			min = arr[a];
//			minIndex = a;
//		}
//	}
//	// maximum number and its index using linear search
//	for (int a = 0; a < Size; ++a)
//	{
//		if (arr[a] > arr[maxIndex])
//		{
//			max = arr[a];
//			maxIndex = a;
//		}
//	}
//	cout << "\nMaximum number in array is " << max << "  at " << maxIndex << endl;
//	cout << "Minimum number in array is " << min << "  at " << minIndex;
//}