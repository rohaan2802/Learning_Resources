///* This program sorts array in ascending order by two ways . 
//Selection sorting and Bubble Sorting . 
//Swap function also used to swap numbers at indexes for sorting */
//#include<fstream>
//#include<iostream>
//using namespace std;
//void bubbleSort(int arr[]);
//void selectionSort(int arr[]);
//void swapNum(int arr[], int var1, int var2);
//const int Size = 10;
//ofstream fout;
//int main()
//{
//	int numArray[Size];
//	int numArray2[Size]; // two arrays used . one for bubble sort and one for selection sort 
//	cout << "Enter 3-digit Numbers in Array :\n";
//	for (int i = 0; i < Size; ++i)
//	{
//		cin >> numArray[i];
//		while (numArray[i] < 100 || numArray[i]>999)
//		{
//			cout << "\n enter three digit number : ";
//			cin >> numArray[i];
//		}
//	}
//	for (int j = 0; j < Size; ++j)
//	{
//		numArray2[j] = numArray[j];
//	}
//	// bubble sort 
//	bubbleSort(numArray);
//	cout << "\n Array after  bubble  Sorting :\n";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << numArray[i] << " ";
//	}
//	// selection sort 
//	selectionSort(numArray2);
//	cout << "\n Array after  Selection Sorting :\n";
//	for (int i = 0; i < Size; ++i)
//	{
//		cout << numArray2[i] << " ";
//	}
//	fout.open("num.txt");
//	if (!(fout.is_open()))
//	{
//		cout << "\nFile cannot be opened .";
//		return 99;
//	}
//	for (int i = 0; i < Size; ++i)// storing sorted array in a text file 
//	{
//		fout << numArray[i] << endl;
//	}
//	cout << endl;
//	system("pause");
//	return 0;
//
//}
//// sorting array by bubble sort method (comparing pairs of index and swapping )
//void bubbleSort(int arr[])
//{
//	for (int i = 0; i < Size; ++i)
//	{
//		for (int j = 0; j < (Size - 1); ++j)
//		{
//			if (arr[j] > arr[j + 1])
//			{
//				swapNum(arr, j, j + 1);
//			}
//		}
//	}
//	
//
//}
//// sorting by seection sort method(comparing one index with others and swapping . then comparing next index and so on)
//void selectionSort(int arr[])
//{
//	int	min;
//	for (int i = 0; i < (Size-1); ++i)
//	{
//		min = i;	// the first index of array is set as minimum with which other indexes will be compared 
//		for (int j = (i+1); j < Size; ++j)	
//		{
//			if (arr[j] < arr[min])  // checks if number at index j is less than number at min index .
//			{  
//				min = j;	//if yes then min is equal to index of new small number 
//		
//			}
//		}
//		swapNum(arr, min, i);
//	}
//}
//void swapNum(int arr[], int var1, int var2) // this function swaps the elements at given indexes
//{
//	int temp = arr[var1];	//temporary variable used to swap 
//	arr[var1] = arr[var2];
//	arr[var2] = temp;
//}
