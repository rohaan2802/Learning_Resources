///* by using a pointer , we print an array . */
//#include<iostream>
//#include<fstream>
//using namespace std;
//int main()
//{
//	double balance[5] = { 1000.0, 2.01, 3.4, 17.0, 50.40 };
//	double *p;
//	p = balance;// here pointer points towards starting address 
//	for (int i = 0; i < 5; ++i)
//	{
//		*p = balance[i]; // at every iteration the pointer indicates to 'i' index of array 
//		cout << *p<<"  ";
//	}
//	cout << endl;
//	system("pause");
//	return 0;
//}