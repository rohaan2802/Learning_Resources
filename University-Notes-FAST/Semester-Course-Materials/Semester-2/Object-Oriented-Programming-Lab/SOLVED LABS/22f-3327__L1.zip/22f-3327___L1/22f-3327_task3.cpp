/* this program perorms a series of initialization using pointers */
//#include<iostream>
//using namespace std;
//int main()
//{
//	int firstvalue = 20, secondvalue = 25;
//	int* p1, * p2;
//	p1 = &firstvalue;
//	p2 = &secondvalue;
//	*p1 = 100;
//	*p2 = *p1;
//	p1 = p2;
//	*p1 = 200;
//	cout << " first value :" << firstvalue << endl;
//	cout << " second value :" << secondvalue << endl;
//	system("pause");
//	return 0;
//}
