//#include<iostream>
//#include<conio.h>
//using namespace std;
//
//int main() 
//{
//    int a = 5, b = 10;  // declare two integer variables and initialize them to 5 and 10 respectively
//    int c;// initialise int tupe variable c
//    int* p1, * p2;  // declare two integer type pointers
//    p1 = &a;  // p1 now points to the memory address of variable a
//    p2 = &b;  // p2 now points to the memory address of variable b
//    c = *p1;  // assign the value of a (which is pointed to by p1) to variable c
//
//    // print the value of *(p1++)
//    cout << "*(p1++) = " << *(p1++) << endl;
//    // This first outputs the value of *p1 (which is 5) and then increments p1 to point to the next memory location.
//    // Since p1 was pointing to the memory location of variable a, p1 now points to the memory location of an unknown value.
//    // The output of *(p1++) is 5.
//
//    // print the adress of p1 which maybe restricted 
//    cout << "\nAddress of p1 " << p1 << endl;
//    // This outputs the current value of p1, which is the memory location of an unknown address in memory.
//
//    // print the value of *(++p1)
//    cout << "\n*(++p1) = " << *(++p1) << endl;
//    // This first increments p1 to point to the next memory location (which is still unknown), and then outputs the value of that location.
//    // Since the memory location is unknown, the output of *(++p1) is unpredictable/arbitrary/garbage value and varies each time the program is run.
//
//    // print the adress of p1 after incrementing again
//    cout << "\naddress of p1 " << p1 << endl;
//    // This outputs the current value of p1, which is the memory location of an unknown value.
//
//    // print the value of (*p1)++
//    cout << "\n(*p1)++ = " << (*p1)++ << endl;
//    // This first gets the value of the unknown memory location pointed to by p1 and outputs it (the output is unpredictable).
//    // Then it increments that value by 1, but does not change the value of p1.
//
//    // print the address of p1
//    cout << "\n address  of p1 " << p1 << endl;
//    // This outputs the current value of p1, which is still the memory location of an unknown value.
//
//    // print the value of ++(*p1)
//    cout << "\n++(*p1) = " << ++(*p1) << endl;
//    // This gets the value of the unknown memory location pointed to by p1 and increments it by 1.
//    // Since the value was already incremented in the previous step, the output of ++(*p1) is unpredictable and can vary each time the program is run.
//
//    // print the address of p1
//    cout << "\naddress of p1 " << p1 << endl;
//    // This outputs the current value of p1, which is still the memory location of an unknown value.
//
//    return 0;
//}
