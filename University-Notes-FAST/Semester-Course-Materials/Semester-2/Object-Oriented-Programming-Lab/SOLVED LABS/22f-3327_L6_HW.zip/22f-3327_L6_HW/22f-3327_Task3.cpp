////Find the error in each of the following segments.If the error can be corrected, explain how.
//a) int* number;// here the pointer is not initialised with a dynamic memory or address of variable. 
//cout << number << endl;//It points to an arbitrary address in memory 
//
//b) double* realPtr;
//long* integerPtr;	 //The datatypes of realPtr and integerPtr are different, so we cannot assign realPtr to integerPtr directly.
//integerPtr = realPtr;// we need to typecast any one of the pointers 
//c) int* x, y;
//x = y;// x=&y;   here the value of y is assigned to x which may the point to a restricted address in memory 
//
//d) char s[] = "this is a character array";
//for (; *s != '\0'; ++s)
//cout << *s << ' ';// s is an array and not a pointer. we cannot increment array like this . ++s not correct 
//
//e) short* numPtr, result;
// void* genericPtr = numPtr;
//result = *genericPtr + 7;// to derefernce a void pointer datatype must be specified explicitly using typecast 
//
//f) double x = 19.34;
//double xPtr = &x;// here xPtr must be a pointer . *xPtr
//cout << xPtr << endl;