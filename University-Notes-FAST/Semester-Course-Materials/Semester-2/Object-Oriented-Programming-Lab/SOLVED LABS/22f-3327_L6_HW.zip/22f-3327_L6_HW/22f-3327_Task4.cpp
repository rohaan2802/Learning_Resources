////Part a)
//#include <iostream>
//using namespace std;
//void mystery1(char*, const char*); // prototype
//int main()
//{
//	char string1[80];
//	char string2[80];
//	cout << "Enter two strings: ";
//	cin >> string1 >> string2;
//	mystery1(string1, string2);
//	cout << string1 << endl;
//} // end main
//// What does this function do?
//void mystery1(char* s1, const char* s2)
//{
//	while (*s1 != '\0')// till it finds a null character it keeps on incrementing the character array
//		++s1;
//	for (; *s1 = *s2; ++s1, ++s2)// adding strig2 at the end of string1 
//		; // empty statement
//} // end function mystery1
///*This program asks the user to enter two strings, and then passes those strings to the mystery1 function.
//The mystery1 function then appends/adds the second string to the end of the first string.
//It does this by using a while loop first to find the end of the first string, and then a for loop to append
//the second string to the end of the first string.Finally, 
//the modified first string is printed to the screen.*/
//
////Part b)
//#include <iostream>
//using namespace std;
//int mystery2(const char*); // prototype
//int main()
//{
//	char string1[80];
//	cout << "Enter a string: ";
//	cin >> string1;
//	cout << mystery2(string1) << endl;
//} // end main
//// What does this function do?
//int mystery2(const char* s)
//{
//	int x;
//	for (x = 0; *s != '\0'; ++s)
//		++x;
//	return x;
//} // end function mystery2
//
///*This program prompts the user to enter a string, and then passes that string to the mystery2 function.
//The mystery2 function then counts the number of characters in the string by using a for loop to iterate 
//through each character in the string, incrementing a counter for each character.
//The function then returns the final count, which is printed to the screen in the main function.*/