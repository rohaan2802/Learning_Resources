#include <iostream>
using namespace std;

int main() 
{
   const char alpha = 'Y'; // declaring and initializing alpha variable

    // Task 1
    char* ptr1 = &alpha; // declaring a pointer pointing to the constant character which is never possible

    *ptr1 = 'Z'; // trying to change the value of alpha using pointer not possible becaause alpha is c
    cout << alpha << endl; // expecting output: Y (since alpha is not changed)

    // Task 2
    char bravo = 'M'; // declaring and initializing bravo variable
    const char* const ptr2 = &alpha; // declaring a constant pointer to the character
    ptr2 = &bravo; // trying to pass address of bravo to the same constant pointer (error: assignment of read-only variable)

    // Task 3
    const char* const ptr3 = &alpha; // declaring a constant pointer to the constant character
    ptr3 = &bravo; // trying to pass address of bravo to the same constant pointer (error: assignment of read-only variable)
    *ptr3 = 'N'; // trying to modify the value of alpha (error: assignment of read-only location)

    return 0;
}
