//#include <iostream>
//#include <string>
//using namespace std;
//// Class 
//class Employee 
//{
//private:
//	string id;
//	string name;
//	string dept;
//	string bankAccountNum;
//	int grade;
//public:
//	// default constructor
//	Employee()
//	{
//		id = "\0";
//		name = "\0";
//		dept = "\0";
//		bankAccountNum = "\0";
//		grade = 0;
//	}
//	// Overloaded/Parametric  constructor
//	Employee(string ID,string Name,string Dept,string accountNUm,int Grade)
//	{
//		id = ID;
//		name = Name;
//		dept = Dept;
//		bankAccountNum = accountNUm;
//		grade = Grade;
//	}
//	// inputData function to take input from user
//	void inputData() 
//	{
//		cout << "Enter your id ( xxxx ): ";
//		cin >> id;
//		cout << "Enter your Name: ";
//		cin >> name;
//		cout << "Enter your department: ";
//		cin >> dept;
//		cout << "Enter your Grade (1 to 8): ";
//		cin >> grade;
//		while (grade > 8 || grade < 1)
//		{
//			cin >> grade;
//		}
//	}
//	// setters 
//	void setId(string Id)
//	{
//		id = Id;
//	}
//	void setName(string Name)
//	{
//		name = Name;
//	}
//	void setDept(string department )
//	{
//		dept = department;
//	}
//	void setAccountNum(string accountNum)
//	{
//		bankAccountNum = accountNum;
//	}
//	void setGrade(int GRADE)
//	{
//		while (GRADE > 8 || GRADE < 1)
//		{
//			cin >> GRADE;
//		}
//		grade = GRADE;
//	}
//	// GETTERS 
//	string getId()
//	{
//		return id;
//	}
//	string getName()
//	{
//		return name;
//	}
//	string getDept()
//	{
//		return dept;
//	}
//	string getAccountNum()
//	{
//		return bankAccountNum;
//	}
//	int getGrade()
//	{
//		return grade;
//	}
//	// Display function 
//	void display() 
//	{
//		cout << "ID: " << id << "   Name: " << name << "   Department: " << dept << endl;
//		cout << "Bank Account No. : " << bankAccountNum << "   Grade: " << grade << endl;
//	}
//	// Destructor
//	~Employee() 
//	{
//		cout << " Destructor is called\n";
//	}
//};
//// main function 
//void main() 
//{
//	// initialize 3 STATIC  objects
//	Employee  obj1, obj2,obj3;
//	// taking input from user 
//	cout << "               INPUTS OF STATIC OBJECTS\n";
//	// using input data function in class 
//	cout << "\nInput of user 1:\n";
//	obj1.inputData();
//	// using setters 
//	cout << "\nInput of user 2 already set .\n";
//	obj2.setId("3277");
//	obj2.setName("Taha");
//	obj2.setDept("BSCS");
//	obj2.setAccountNum("1234567");
//	obj2.setGrade(2);
//	// using paramteric function in class 
//	cout << "\nInput of user 3:\n";
//	obj3.inputData();
//	cout << endl;
//
//	cout << "\n              OUTPUTS\n";
//	obj1.display();
//	cout << endl;
//	cout<<obj2.getId()<<endl;
//	cout<<obj2.getName()<<endl;
//	cout<<obj2.getDept()<<endl;
//	cout<<obj2.getAccountNum()<<endl;
//	cout<<obj2.getGrade()<<endl;
//	cout << endl;
//	obj3.display();
//	cout << endl;
//	// Explicit Destructors calls
//	obj1.~Employee();
//	obj2.~Employee();
//	obj3.~Employee();
//	cout << endl << endl << endl;
//
//
//	//// allocate 3 DYNAMIC objects
//	Employee* obj4=new Employee, * obj5=new Employee, * obj6=new Employee;
//	// taking input from user 
//	cout << "               INPUTS OF DYNAMIC OBJECTS \n";
//	cout << "\n Input of user 1 :\n";
//	obj4->inputData();
//	cout << "\n Input of user 2 :\n";
//	obj5->inputData();
//	cout << "\n Input of user 3 :\n";
//	obj6->inputData();
//	
//	// Outputs
//	cout << "\n                         OUTPUTS\n";
//	obj4->display();
//	obj5->display();
//	obj6->display();
//	// Explicit Destructors calls
//	cout << "=========================\n";
//	obj4->~Employee();
//	obj5->~Employee();
//	obj6->~Employee();
//
//	// deallocation of DMA
//	delete obj4;
//	delete obj5;
//	delete obj6;
//
//	system("pause");
//
//}
