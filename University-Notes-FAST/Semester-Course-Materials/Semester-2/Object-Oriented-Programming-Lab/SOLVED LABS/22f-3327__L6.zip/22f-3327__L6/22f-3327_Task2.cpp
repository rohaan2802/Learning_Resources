//#include <iostream>
//#include <string>
//using namespace std;
//// class of Person
//class Person
//{
//private:
//	string name;
//    string dob;
//    string cnic;
//	string MaritalStatus;
//public:
//	// default constructor
//	Person() 
//	{
//		name = "";
//		dob = " date  month  year ";
//		cnic = "xxxxx-xxxxxxx-x";
//		MaritalStatus = "N/A";
//	}
//	void setName()
//	{
//		name = "Mr.X ";
//		
//		
//		
//	}
//	void setDOB()
//	{
//		dob = " 1st January 2001";
//	}
//	void setCNIC()
//	{
//		cnic = "xxxxx-xxxxxxx-x";
//	}
//	void setStatus()
//	{
//		MaritalStatus = "Married";
//	}
//	
//	string getDob()
//	{
//		return dob;
//	}
//	string getCNIC()
//	{
//		return cnic;
//	}
//	// display function
//	void display()
//	{
//		cout << name << "    " << getDob() << "    " << getCNIC()<<"\t\t Married"<<endl;
//	}
//
//};
//// main function 
//void main() 
//{
//	Person man1;
//	man1.setName();
//	man1.setDOB();
//	man1.setCNIC();
//	man1.setStatus();
//	man1.display();
//	system("pause");
//}
