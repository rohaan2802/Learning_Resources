//#include "22f-3327_Interface2.h"
//
//Polygon::Polygon(float len = 0, float wid = 0)
//{
//    length = len;
//    width = wid;
//}
// Square::Square(float len)
//{
//    length = len;
//    width = len;
//}
//
// float Square::Area()
//{
//    return length * length;
//}
//
// float Square::Perimeter()
//{
//    return 4 * length;
//}
//
// void Square::Display()
//{
//    cout << "Area of Square: " << Area() << endl;
//    cout << "Perimeter of Square: " << Perimeter() << endl;
//}
//
// Rectangle::Rectangle(float len, float wid)
//{
//    length = len;
//    width = wid;
//}
//
// float Rectangle::Area()
//{
//    return length * width;
//}
//
// float Rectangle::Perimeter() {
//    return 2 * (length + width);
//}
//
// void Rectangle::Display()
//{
//    cout << "Area of Rectangle: " << Area() << endl;
//    cout << "Perimeter of Rectangle: " << Perimeter() << endl;
//}
//
// Triangle::Triangle(float s1, float s2, float s3)
//{
//    side1 = s1;
//    side2 = s2;
//    side3 = s3;
//}
//
// float Triangle::Area()
//{
//    float s = (side1 + side2 + side3) / 2;
//    return sqrt(s * (s - side1) * (s - side2) * (s - side3));
//}
//
// float Triangle::Perimeter()
//{
//    return side1 + side2 + side3;
//}
//
// void Triangle::Display()
//{
//    cout << "Area of Triangle: " << Area() << endl;
//    cout << "Perimeter of Triangle: " << Perimeter() << endl;
//}
