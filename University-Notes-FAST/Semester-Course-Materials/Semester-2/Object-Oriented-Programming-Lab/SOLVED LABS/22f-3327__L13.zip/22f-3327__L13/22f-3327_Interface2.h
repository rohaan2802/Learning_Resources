//#pragma once
//#include<iostream>
//using namespace std;
//
//class Polygon {
//protected:
//    float length, width;
//public:
//    Polygon(float,float);
//    virtual float Area() = 0;
//    virtual float Perimeter() = 0;
//    virtual void Display() = 0;
//    virtual ~Polygon() {}
//};
//
//class Square : public Polygon {
//public:
//    Square(float len = 0);
//    float Area();
//    float Perimeter();
//    void Display();
//};
//
//class Rectangle : public Polygon
//{
//public:
//    Rectangle(float len = 1, float wid = 1);
//    float Area();
//    float Perimeter();
//    void Display();
//};
//
//class Triangle : public Polygon
//{
//private:
//    float side1, side2, side3;
//public:
//    Triangle(float s1 = 1, float s2 = 1, float s3 = 1);
//    float Area();
//    float Perimeter();
//    void Display();
//};
