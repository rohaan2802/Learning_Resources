//#pragma once
//#include<string>
//#include<iostream>
//using namespace std;
//class Ship 
//{
//private:
//    string name;
//    string yearBuilt;
//public:
//    Ship(const string& Name, const string& YearBuilt);
//    // Accessors
//    string getName() const;
//    string getYearBuilt() const;
//
//    // Mutators
//    void setName(const string& name);
//    void setYearBuilt(const string& yearBuilt);
//
//    // Virtual print function
//    virtual void print() const;
//};
//
//
//class CruiseShip : public Ship 
//{
//private:
//    int maxPassengers;
//public:
//    CruiseShip(const string& name, const string& yearBuilt, int MaxPassengers);
//    // Accessors
//    int getMaxPassengers() const;
//    // Mutators
//    void setMaxPassengers(int maxPassengers);
//    // Override the print function from the base class
//    void print() const ;
//
//};
//
//
//class CargoShip : public Ship 
//{
//private:
//    int cargoCapacity;
//public:
//    CargoShip(const string& name, const string& yearBuilt, int CargoCapacity);
//
//    // Accessors
//    int getCargoCapacity() const;
//
//    // Mutators
//    void setCargoCapacity(int cargoCapacity);
//
//    // Override the print function from the base class
//    void print() const ;
//};
//
