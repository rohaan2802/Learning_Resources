#pragma once
#include<iostream>
using namespace std;
class Bill 
{
protected:
	int units;
	int per_unit_cost;
	float calBill;
public:
	Bill(int Unit, int perUnit, float cal );
	virtual float Monthly_bill()=0;
	virtual void Bill_Display()=0;
	virtual ~Bill() {}
};
class January_bill:public Bill
{
public:
	January_bill(int Unit, int perUnit);
	void Bill_Display();
	float Monthly_bill();
};
class February_bill :public Bill 
{
public:
	February_bill(int Unit, int perUnit);
	void Bill_Display();
	float Monthly_bill();
};
class March_bill :public Bill 
{
public:
	March_bill(int Unit, int perUnit);
	void Bill_Display();
	float Monthly_bill();
};
class April_bill :public Bill 
{
public:
	April_bill(int Unit, int perUnit);
	void Bill_Display();
	float Monthly_bill();
};
class May_bill :public Bill 
{
public:
	May_bill(int Unit, int perUnit);
	void Bill_Display();
	float Monthly_bill();
};

