#include<iostream>
#include"22f-3327_Interface3.h"
int main() {
    Bill* bills[5];
    bills[0] = new January_bill(100,15);
    bills[1] = new February_bill(200,18);
    bills[2] = new March_bill(300,17);
    bills[3] = new April_bill(400,19);
    bills[4] = new May_bill(500,20);

 
    for (int i = 0; i < 5; i++) 
    {
        bills[i]->Bill_Display();
        bills[i]->~Bill();// deleting object after need finish 
        delete bills[i];
    }
    cout << endl;
    system("pause");
    return 0;
}