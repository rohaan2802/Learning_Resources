//#include<iostream>
//#include"22f-3327_Interface1.h"
//using namespace std;
//int main() {
//    // Create an array of Ship pointers
//    const int numShips = 3;
//    Ship* ships[numShips];
//
//    // Initialize array elements with dynamically allocated objects
//    ships[0] = new Ship("Red Dragon", "2069");
//    ships[1] = new CargoShip("Taha Cargo ", "2003", 223321);
//    ships[2] = new CruiseShip("Titanic", "1912", 4000);
//
//    // Call print function for each object in the array
//    for (int i = 0; i < numShips; ++i) 
//    {
//        ships[i]->print();
//        cout << endl;
//    }
//    for (int i = 0; i < numShips; ++i) 
//    {
//        delete ships[i];
//    }
//    system("pause");
//    return 0;
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////class Ship {
////private:
////	string name;
////	string yearBuilt;
////public:
////    Ship(const string& Name, const string& YearBuilt): name(Name), yearBuilt(YearBuilt) {}
////    // Accessors
////    string getName() const 
////    { 
////        return name;
////    }
////    string getYearBuilt() const
////    { 
////        return yearBuilt; 
////    }
////
////    // Mutators
////    void setName(const string& name) 
////    {
////        this->name = name; 
////    }
////    void setYearBuilt(const string& yearBuilt) 
////    {
////        this->yearBuilt = yearBuilt;
////    }
////
////    // Virtual print function
////    virtual void print() const //const because function doesn't need to change value of any member variable
////    {
////        cout << "Ship name: " << name << endl;
////        cout << "Year built: " << yearBuilt << endl;
////    }
////};
////class CruiseShip : public Ship {
////public:
////    CruiseShip(const string& name, const string& yearBuilt, int MaxPassengers): Ship(name, yearBuilt), maxPassengers(MaxPassengers) {}
////
////    // Accessors
////    int getMaxPassengers() const { return maxPassengers; }
////
////    // Mutators
////    void setMaxPassengers(int maxPassengers) { this->maxPassengers = maxPassengers; }
////
////    // Override the print function from the base class
////    void print() const  {
////        cout << "Cruise ship name: " << getName() << endl;
////        cout << "Max passengers: " << maxPassengers << endl;
////    }
////
////private:
////    int maxPassengers;
////};
////class CargoShip : public Ship {
////public:
////    CargoShip(const string& name, const string& yearBuilt, int CargoCapacity): Ship(name, yearBuilt), cargoCapacity(CargoCapacity) {}
////
////    // Accessors
////    int getCargoCapacity() const
////    {
////        return cargoCapacity; 
////    }
////
////    // Mutators
////    void setCargoCapacity(int cargoCapacity)
////    { 
////        this->cargoCapacity = cargoCapacity;
////    }
////
////    // Override the print function from the base class
////    void print() const 
////    {
////        cout << "Cargo ship name: " << getName() << endl;
////        cout << "Cargo capacity: " << cargoCapacity << " tons" << endl;
////    }
////
////private:
////    int cargoCapacity;
////};