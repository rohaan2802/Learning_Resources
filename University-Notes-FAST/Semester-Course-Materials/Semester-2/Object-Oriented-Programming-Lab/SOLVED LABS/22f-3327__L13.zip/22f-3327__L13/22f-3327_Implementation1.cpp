//#include"22f-3327_Interface1.h"
///////////////////////////////////   CLASS SHIP
//Ship::Ship(const string& Name, const string& YearBuilt)
//{
//    this->name = Name;
//    this->yearBuilt = YearBuilt;
//}
//string Ship::getName() const
//{
//    return name;
//}
//string Ship::getYearBuilt() const 
//{
//    return yearBuilt; 
//}
//void  Ship::setName(const string& name) 
//{
//    this->name = name;
//}
//void  Ship::setYearBuilt(const string& yearBuilt)
//{
//    this->yearBuilt = yearBuilt; 
//}
//void  Ship::print() const 
//{
//    cout << "Ship name: " << name << endl;
//    cout << "Year built: " << yearBuilt << endl;
//}
//
//
///////////////////////////////////////////CLASS CRUISESHIP
//CruiseShip::CruiseShip(const string& name, const string& yearBuilt, int MaxPassengers) : Ship(name, yearBuilt), maxPassengers(MaxPassengers) {}
//int CruiseShip::getMaxPassengers() const
//{ 
//    return maxPassengers; 
//}
//void CruiseShip::setMaxPassengers(int maxPassengers)
//{
//    this->maxPassengers = maxPassengers; 
//}
//void CruiseShip::print() const
//{
//    cout << "Cruise ship name: " << getName() << endl;
//    cout << "Max passengers: " << maxPassengers << endl;
//}
//
/////////////////////////////////////////////////CLASS  CARGO SHIP
//CargoShip::CargoShip(const string& name, const string& yearBuilt, int CargoCapacity) : Ship(name, yearBuilt), cargoCapacity(CargoCapacity) {}
//int CargoShip::getCargoCapacity() const
//{
//    return cargoCapacity;
//}
//void CargoShip::setCargoCapacity(int cargoCapacity)
//{
//    this->cargoCapacity = cargoCapacity;
//}
//void CargoShip::print() const
//{
//    cout << "Cargo ship name: " << getName() << endl;
//    cout << "Cargo capacity: " << cargoCapacity << " tons" << endl;
//}
