#include"22f-3327_Interface3.h"

Bill::Bill(int Unit = 0, int perUnit = 0, float cal = 0) : units(Unit), per_unit_cost(perUnit),calBill(cal){}

January_bill::January_bill(int Unit, int perUnit) :Bill(Unit, perUnit, 0) {}
float January_bill::Monthly_bill()
{
	calBill = units * per_unit_cost;
	return calBill;
}
void January_bill::Bill_Display()
{
	cout << "\n January Bill:Rs." << Monthly_bill();
}

February_bill::February_bill(int Unit, int perUnit) :Bill(Unit, perUnit, 0) {}
float February_bill::Monthly_bill()
{
	calBill = units * per_unit_cost;
	return calBill;
}
void February_bill::Bill_Display()
{
	cout << "\n February Bill:Rs." << Monthly_bill();
}

March_bill::March_bill(int Unit, int perUnit) :Bill(Unit, perUnit, 0) {}
float March_bill::Monthly_bill()
{
	calBill = units * per_unit_cost;
	return calBill;
}
void March_bill::Bill_Display()
{
	cout << "\n March Bill:Rs." << Monthly_bill();
}

April_bill::April_bill(int Unit, int perUnit) :Bill(Unit, perUnit, 0) {}
float April_bill::Monthly_bill()
{
	calBill = units * per_unit_cost;
	return calBill;
}
void April_bill::Bill_Display()
{
	cout << "\n April Bill:rs." << Monthly_bill();
}

May_bill::May_bill(int Unit, int perUnit) :Bill(Unit, perUnit, 0) {}
float May_bill::Monthly_bill()
{
	calBill = units * per_unit_cost;
	return calBill;
}
void May_bill::Bill_Display()
{
	cout << "\n May Bill:Rs." << Monthly_bill();
}

