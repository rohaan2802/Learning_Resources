//#pragma once
//#include<iostream>
//#include"22f-3327_Interface2.h"
//using namespace std;
//
//int main() 
//{
//    Polygon* bptr;
//    cout << "\nSide of Square is 4\n";
//    Square square(4);
//    bptr = &square;
//    bptr->Display();
//    cout << endl << endl;
//
//    cout << "\nSides of Rectangle are 5 and 6\n";
//    Rectangle rectangle(5, 6);
//    bptr = &rectangle;
//    bptr->Display();
//    cout << endl << endl;
//
//    cout << "\nSides of Triangle are 3 ,4 ,5\n";
//    Triangle triangle(3, 4, 5);
//    bptr = &triangle;
//    bptr->Display();
//    cout << endl << endl;
//
//    system("pause");
//    return 0;
//}
//
//
//
//

























//class Polygon {
//protected:
//    float length, width;
//public:
//    Polygon(){}
//    virtual float Area() = 0;
//    virtual float Perimeter() = 0;
//    virtual void Display() = 0;
//virtual ~Polygon(){}
//};
//
//class Square : public Polygon {
//public:
//    Square(float len=0) 
//    {
//        length = len;
//        width = len;
//    }
//    float Area() 
//    {
//        return length * length;
//    }
//    float Perimeter() 
//    {
//        return 4 * length;
//    }
//    void Display() 
//    {
//        cout << "Area of Square: " << Area() << endl;
//        cout << "Perimeter of Square: " << Perimeter() << endl;
//    }
//};
//
//class Rectangle : public Polygon 
//{
//public:
//    Rectangle(float len=1, float wid=1) 
//    {
//        length = len;
//        width = wid;
//    }
//    float Area() 
//    {
//        return length * width;
//    }
//    float Perimeter() {
//        return 2 * (length + width);
//    }
//    void Display() 
//    {
//        cout << "Area of Rectangle: " << Area() << endl;
//        cout << "Perimeter of Rectangle: " << Perimeter() << endl;
//    }
//};
//
//class Triangle : public Polygon 
//{
//private:
//    float side1, side2, side3;
//public:
//    Triangle(float s1=1, float s2=1, float s3=1) 
//    {
//        side1 = s1;
//        side2 = s2;
//        side3 = s3;
//    }
//    float Area()
//    {
//        float s = (side1 + side2 + side3) / 2;
//        return sqrt(s * (s - side1) * (s - side2) * (s - side3));
//    }
//    float Perimeter()
//    {
//        return side1 + side2 + side3;
//    }
//    void Display() 
//    {
//        cout << "Area of Triangle: " << Area() << endl;
//        cout << "Perimeter of Triangle: " << Perimeter() << endl;
//    }
//};