//using namespace std;
//// engine, wheel, window, door 
//class Engine
//{
//	int horsepower;
//	bool is_twinturbo;
//public: 
//	Engine();
//	void setEngine(int, bool);
//	void getEngine();
//};
//class Wheel
//{
//	int wheelSize;
//	bool is_racingWheel;
//public:
//	Wheel();
//	void setWheel(int, bool);
//	void getWheel();
//};
//class Window
//{
//	int noOfWindows;
//	bool is_tinted;
//public:
//	Window();
//	void setWindow(int, bool);
//	void getWindow();
//};
//class Door
//{
//	int noOfDoor;
//	bool is_butterflyDoor;
//public:
//	Door();
//	void setDoor(int, bool);
//	void getDoor();
//};
//class Car 
//{
//	Engine engine;
//	Wheel wheel;
//	Door door;
//	Window window;
//public:
//	Car();
//	Car(int, bool, int, bool, int, bool, int, bool);
//	void setCar_engine(int,bool);
//	void setCar_window(int, bool);
//	void setCar_door(int, bool);
//	void setCar_wheel(int, bool);
//	void getCar_engine();
//	void getCar_window();
//	void getCar_door();
//	void getCar_wheel();
//};
