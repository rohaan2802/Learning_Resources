//#include<string>
//#include<iostream>
//#include"22f-3327_Interface6.h"
//using namespace std;
//
//    Person::Person()
//    {
//        name = "";
//        age = 0;
//    }
//    Person:: Person(string Name, int age)
//    {
//        name = Name;
//        this->age = age;
//
//    }
//    string Person::getName()
//    {
//        return name;
//    }
//    int Person::getAge()
//    {
//        return age;
//    }
//
//
//
//    Address::Address()
//    {
//        street = "";
//        houseNumber = " ";
//        for (int i = 0; i < 3; i++)
//        {
//            persons[i] = nullptr;
//
//        }
//    }
//    Address::Address(string s, string h, Person* p1)
//    {
//        street = s;
//        houseNumber = h;
//        for (int i = 0; i < 3; i++)
//        {
//            persons[i] = p1++;
//
//        }
//    }
//    string Address::getStreet()
//    {
//        return street;
//    }
//    string Address::getHouseNumber() 
//    {
//        return houseNumber;
//    }
//    Person* Address::getPerson(int i) 
//    {
//        return persons[i];
//    }
//    Address::~Address(){}
//
