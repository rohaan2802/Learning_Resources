#include <iostream>
using namespace std;
class Person
{
private:
    string name;
    int age;
public:
    Person();
    Person(string n, int a);
    string getName();
    int getAge();

};

class Teachers
{
private:
    string course;
    Person* persons[3];

public:

    Teachers();
    Teachers(string c, Person* p1);
    string getCourse();
    void setCousre(string c);
    Person* getPerson(int i);
    ~Teachers();
}; 
