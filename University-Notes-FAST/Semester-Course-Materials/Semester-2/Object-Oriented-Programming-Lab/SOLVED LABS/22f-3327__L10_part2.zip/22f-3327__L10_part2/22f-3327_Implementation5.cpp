//#include"22f-3327_Interface5.h"
//#include<iostream>
//#include<string>
//using namespace std;
//// engine, wheel, window, door 
//
//	Engine::Engine(){}
//
//	void Engine::setEngine(int horsepow, bool isTurbo)
//	{
//		horsepower = horsepow;
//		is_twinturbo = isTurbo;
//	}
//	void Engine::getEngine()
//	{
//		cout << horsepower << " horsepower \n";
//		if (is_twinturbo == 1)
//			cout << " Car has a twin turbo engine .\n";
//	}
//
//
//	Wheel::Wheel(){}
//	void Wheel::setWheel(int size, bool sports) 
//	{
//		wheelSize = size;
//		is_racingWheel = sports;
//	}
//	void Wheel::getWheel()
//	{
//		cout << wheelSize << " inch wheels \n";
//		if (is_racingWheel == 1)
//			cout << " Car has racing wheels .\n";
//	}
//
//	Window::Window(){}
//	void Window::setWindow(int windowNum, bool tinted) 
//	{
//		noOfWindows = windowNum;
//		is_tinted = tinted;
//	}
//	void Window::getWindow()
//	{
//		cout << noOfWindows << " windows  \n";
//		if (is_tinted == 1)
//			cout << " Car has tinted windows  .\n";
//	}
//
//	Door::Door() {}
//	void Door::setDoor(int doorNum, bool doorType)
//	{
//		noOfDoor = doorNum;
//		is_butterflyDoor = doorType;
//	}
//	void Door::getDoor()
//	{
//		cout << noOfDoor << " doors  \n";
//		if (is_butterflyDoor == 1)
//			cout << " Car has Butterfly doors  .\n";
//	}
//
//
//	Car::Car(){}
//	Car::Car(int horsepow, bool turbo, int size, bool sports, int doorNum, bool type, int windowNum, bool tinted)
//	{
//		engine.setEngine(horsepow, turbo);
//		wheel.setWheel(size, sports);
//		door.setDoor(doorNum, type);
//		window.setWindow(windowNum, tinted);
//	}
//	void Car::setCar_engine(int horsepow, bool turbo)
//	{
//		engine.setEngine(horsepow, turbo);
//	}
//	void Car::setCar_wheel(int size, bool sports)
//	{
//		wheel.setWheel(size, sports);
//	}
//	void Car::setCar_door(int doorNum, bool type)
//	{
//		door.setDoor(doorNum, type);
//	}
//	void Car::setCar_window(int windowNum, bool tinted)
//	{
//		window.setWindow(windowNum, tinted);
//	}
//	void Car::getCar_engine()
//	{
//		engine.getEngine();
//	}
//	void Car::getCar_window()
//	{
//		window.getWindow();
//	}
//	void Car::getCar_door()
//	{
//		door.getDoor();
//	}
//	void Car::getCar_wheel()
//	{
//		wheel.getWheel();
//	}
