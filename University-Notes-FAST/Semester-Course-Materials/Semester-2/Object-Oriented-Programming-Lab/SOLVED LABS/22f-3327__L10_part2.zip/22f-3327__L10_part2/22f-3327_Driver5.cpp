//#include<iostream>
//#include"22f-3327_Interface5.h"
//using namespace std;
//int main()
//{
//	Car ferrari;
//	cout << "\t FERRARI\n";
//	ferrari.setCar_engine(1200, 1);
//	ferrari.setCar_wheel(4, 1);
//	ferrari.setCar_door(2, 1);
//	ferrari.setCar_window(4, 1);
//	ferrari.getCar_engine();
//	ferrari.getCar_wheel();
//	ferrari.getCar_window();
//	ferrari.getCar_door();
//	cout << "\n\n\n\t Toyota Corolla\n";
//	Car toyota_corolla(700,0,4,0,4,0,4,1);
//	toyota_corolla.getCar_engine();
//	toyota_corolla.getCar_wheel();
//	toyota_corolla.getCar_window();
//	toyota_corolla.getCar_door();
//}