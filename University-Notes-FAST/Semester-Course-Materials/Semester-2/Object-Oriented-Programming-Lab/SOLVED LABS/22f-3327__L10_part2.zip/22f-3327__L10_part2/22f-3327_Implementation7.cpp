#include <iostream>
#include "22f-3327_Interface7.h"
using namespace std;

Person::Person()
{
    name = "";
    age = 0;
}
Person::Person(string Name, int Age)
{
    name = Name;
    age = Age;

}
string Person::getName()
{
    return name;
}
int Person::getAge()
{
    return age;
}
Teachers::Teachers()
{
    course = " ";
    for (int i = 0; i < 3; i++)
    {
        persons[i] = nullptr;

    }

}
Teachers::Teachers(string c, Person* p1)
{
    course = c;

    for (int i = 0; i < 3; i++)
    {

        persons[i] = p1++;

    }
}


string Teachers::getCourse()
{
    return course;
}

void Teachers::setCousre(string c)
{
    course = c;
}

Person* Teachers::getPerson(int i)
{
    return persons[i];
}


Teachers::~Teachers()
{
}