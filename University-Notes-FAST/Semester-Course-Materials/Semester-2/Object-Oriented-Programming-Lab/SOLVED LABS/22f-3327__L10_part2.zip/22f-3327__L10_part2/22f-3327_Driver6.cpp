//#include <string>
//#include <iostream>
//#include"22f-3327_Interface6.h"
//using namespace std;
//int main() {
//
//    Person* p = new Person[3];
//    p[0] = Person("saad ", 23);
//    p[1] = Person("maaz ", 21);
//    p[2] = Person("hood", 44);
//
//    Address* a = new Address("st 4,jaranwala", "434", p);
//
//
//    cout << "Address: " << a->getHouseNumber() << endl << a->getStreet() << endl;
//
//    cout << "Persons with same address:" << endl;
//    for (int i = 0; i < 3; i++)
//    {
//        cout << a->getPerson(i)->getName() << " age: " << a->getPerson(i)->getAge()  << endl;
//    }
//
//    // Clean up memory
//    delete[] p;
//    delete a;
//
//    return 0;
//}