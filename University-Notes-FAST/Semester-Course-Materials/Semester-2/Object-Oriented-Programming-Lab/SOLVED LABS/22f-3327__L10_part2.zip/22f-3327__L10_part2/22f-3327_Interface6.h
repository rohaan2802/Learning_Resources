//using namespace std;
//class Person 
//{
//private:
//    string name;
//    int age;
//public:
//    Person();
//    Person(string,int);
//    string getName();
//    int getAge();
//};
//
//class Address
//{
//private:
//    string street;
//    string houseNumber;
//    Person* persons[3];
//
//public:
//
//    Address();
//    Address(string s, string h, Person* p1);
//    string getStreet();
//    string getHouseNumber();
//    Person* getPerson(int i);
//    ~Address();
//};
//
