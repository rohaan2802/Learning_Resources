#include <iostream>
#include "22f-3327_Interface7.h"
using namespace std;
int main() {

    Person* p = new Person[3];
    p[0] = Person("Ma'am Maham", 30);
    p[1] = Person("Ma'am Rimsha", 25);
    p[2] = Person("Ma'am Momina", 35);

    Teachers t("PF", p);

    cout << "Course Teacher: " << t.getCourse() << endl;

    for (int i = 0; i < 3; i++)
    {
        cout << t.getPerson(i)->getName() << "\t Age:" << t.getPerson(i)->getAge()  << endl;
    }

    delete[] p;
    p = nullptr;


    return 0;
}