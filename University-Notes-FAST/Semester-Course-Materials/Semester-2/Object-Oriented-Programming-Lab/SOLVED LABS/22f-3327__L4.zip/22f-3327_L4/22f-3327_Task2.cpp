//// print fibonacci series till a given number using recursion
//#include<iostream>
//using namespace std;
//int fibonacci(int, int, int, int);
//void main()
//{
//	int n;
//	cout << "Enter a number till which you want to print fibonacci series: "; 
//	cin >> n;
//	cout << "Fibonacci series is : 0 1";
//	fibonacci(n- 2, 0, 1, 1);// n-2 because we already know the first and second number 
//	cout << endl;
//	system("pause");
//}
//int fibonacci(int num , int first , int second , int i)  //bottom to top approach used 
//{
//	int temp = first + second;// calculates next fibonacci number every time by adding previous two
//	first= second;// updating second number after calculating fibonacci 
//	second = temp ;// updating first number after calculating fibonacci 
//	cout << " " << second;
//	if (i == num)// start from 1 and checks till it reaches the num
//		return 0;
//	else
//	{
//		i++;
//		return fibonacci(num,first,second,i);
//	}
//}