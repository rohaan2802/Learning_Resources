#include<iostream>
using namespace std;
struct Distance
{
	int feet;
	float inches;
};
void main()
{
	Distance d1, d2, d3;
	cout << "Enter feet of room 1:";
	cin >> d1.feet;
	cout << "Enter inches of room 1:";
	cin >> d1.inches;
	if (d1.inches > 12)
	{
		d1.feet += d1.inches / 12.0;
		d1.inches -= (static_cast<int>(d1.inches / 12)) * 12.0;
	}
	d2 = { 10,5.25 };
	if (d2.inches > 12)
	{
		d2.feet += d2.inches / 12.0;
		d2.inches -= (static_cast<int>(d2.inches / 12)) * 12.0;
	}
	d3.feet = d1.feet + d2.feet;
	d3.inches = d1.inches + d2.inches;
	if (d3.inches > 12)
	{
		d3.feet += d3.inches / 12.0;
		d3.inches -= (static_cast<int>(d3.inches / 12)) * 12.0;
	}
	cout << "\n For Room 1 : \nfeet=" << d1.feet << "\ninches=" << d1.inches << endl << endl;
	cout << "\n For Room 2 : \nfeet=" << d2.feet << "\ninches=" << d2.inches << endl << endl;
	cout << "\n For Room 3 : \nfeet=" << d3.feet << "\ninches=" << d3.inches << endl << endl;
	system("pause");
}