//#include<iostream>
//using namespace std;
//struct car 
//{
//	char carName[20];
//	char carModel[20];
//	int yearModel;
//	double cost;
//};
//void main()
//{
//	car Car1,Car2;
//	Car1 = { "Ford","Raptor",2019,250000 };
//	Car2 = { "Bugatti","Chiron",2017,520000};
//	if (Car1.cost > Car2.cost)
//		cout << "\n Car with highest cost is :" << Car1.carName;
//	else 
//		cout << "\n Car with highest cost is :" << Car2.carName;
//	cout << "\n *******Data Through Objects*******\n";
//
//	cout << "Data through Car 1:\n";
//	cout << "Name:" << Car1.carName<<endl;
//	cout << "Model:" << Car1.carModel << endl;
//	cout << "Year Model:" << Car1.yearModel << endl;
//	cout << "Cost:" << Car1.cost<< endl<<endl<<endl;
//
//	cout << "Data through Car 2:\n";
//	cout << "Name:" << Car2.carName << endl;
//	cout << "Model:" << Car2.carModel << endl;
//	cout << "Year Model:" << Car2.yearModel << endl;
//	cout << "Cost:" << Car2.cost << endl;
//	system("pause");
//}
