///* by using a recursive function we calculate sum of all numbers from 0 till a given number */
//#include<iostream>
//using namespace std;
//
//int summation(int num)// calculates sum of numbers from given number till 0
//{
//	if (num == 1)
//		return 1;
//	else
//		return num + summation(num - 1);
//}
//void main()
//{
//	int n, sum; float average=0;// initializing variables
//	cout << "Enter a number:"; cin >> n;
//	sum=summation(n);// calling function
//	average = sum / n;//calculating average 
//	cout << "\nThe Sum is :" << sum << " \n Average is :" << average<<endl;
//	system("pause");
//}