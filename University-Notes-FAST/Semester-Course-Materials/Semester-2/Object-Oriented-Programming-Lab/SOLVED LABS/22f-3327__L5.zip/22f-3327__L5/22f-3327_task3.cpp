#include<iostream>
using namespace std;
enum week 
{  
	temporary,
	monday,
	tuesday, 
	wednesday, 
	thursday, 
	friday, 
	saturday,
	sunday
};
void main()
{
	week today;
	today = wednesday;
	cout << "\n today is wednesday : 3";
	cout << "\n so Yestrerday was :" << today-1 ;
	cout << "\n tomorrow will be :" << today+1 << endl;;
	system("pause");
}