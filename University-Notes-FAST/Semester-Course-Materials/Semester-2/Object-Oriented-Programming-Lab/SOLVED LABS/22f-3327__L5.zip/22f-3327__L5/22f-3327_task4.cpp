//#include<iostream>
//#include<string>
//using namespace std;
//// class of Date 
//class Date
//{
//private:
//	int day;
//	int month;
//	int year;
//	string str = { ",January,March,April,May,June,July,August,September,October,November,December," };
//public:
//	// initialize constructor
//	Date()// standard constructor that initializes day date and year to 0
//	{
//		day = month = year = 0;
//	}
//	Date(int d, int m, int y)	// user input date 
//	{
//		day = d;
//		month = m;
//		year = y;
//	}
//	// month function
//	void displayMonth()
//	{
//		switch (month)
//		{
//		case 1 : 
//			cout << "January";
//			break;
//		case 2:
//			cout << ",February";
//			break;
//		case 3:
//			cout << "March";
//			break;
//		case 4:
//			cout << "April";
//			break;
//		case 5:
//			cout << "May";
//			break;
//		case 6:
//			cout << "June";
//			break;
//		case 7:
//			cout << "July";
//			break;
//		case 8:
//			cout << "August";
//			break;
//		case 9:
//			cout << "September";
//			break;
//		case 10:
//			cout << "October";
//			break;
//		case 11:
//			cout << "November";
//			break;
//		case 12:
//			cout << "December";
//			break;
//		default: 
//			cout << "\nInvalid Input";
//		}
//	}
//	// functions of display 
//	void displayType01()
//	{
//		cout << "Date : " << day << "/" << month << "/" << year << endl;
//	}
//	void displayType02()
//	{
//		cout << "Date : ";
//		displayMonth();
//		cout << " " << day << ", " << year << endl;
//	}
//
//	void displayType03()
//	{
//		cout << "Date : " << day << " ";
//		displayMonth();
//		cout << " " << year << endl;
//	}
//};
//// main function
//int main()
//{
//	cout << "=========================================\n";
//	int Day = 0, Month = 0, Year = 0, option = 0;
//	cout << "Enter day: ";
//	cin >> Day;
//	while (Day < 1 || Day > 31)
//	{
//		cout << "Invalid Input .Try Again: ";
//		cin >> Day;
//	}
//	cout << "\n\nEnter month: ";
//	cin >> Month;
//	while (Month < 1 || Month > 12)
//	{
//		cout << "Invalid Input .Try Again: ";
//		cin >> Month;
//	}
//	cout << "\n\nEnter year: ";
//	cin >> Year;
//	Date date(Day, Month, Year);
//	cout << "=========================================\n";
//	cout << "                  MENU\n";
//	cout << "=========================================\n";
//	cout << "1. dd/mm/yyyy  ( 20/6/2001 )\n";
//	cout << "2. Month Day, year (June 2, 2001 )\n";
//	cout << "3. Day Month Year ( 2 June 2001 )\n";
//	cout << "=========================================\n";
//	cout << "Select Option: ";
//	cin >> option;
//	cout << "=========================================\n";
//	switch (option) {
//	case 1:
//		date.displayType01();
//		break;
//	case 2:
//		date.displayType02();
//		break;
//	case 3:
//		date.displayType03();
//		break;
//	default:
//		cout << "Invalid input\n";
//		break;
//	}
//	cout << "=========================================\n";
//
//	system("pause");
//	return 0;
//}