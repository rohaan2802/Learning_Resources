///* program first takes input of 3 players and then by menu driven program asks user to 
//1.search and update 
//2.input again 
//3.output data
//4. exit program
//*/
//#include <iostream>
//using namespace std;
//structure of Player 
//struct Player 
//{
//	string name;
//	int no_of_home_runs = 0;
//	int no_of_hits = 0;
//};
// Prototypes of function
//void inputData(Player&);
//void searchPlayer(Player*);
//void displayData(Player*);
//
// Main function 
//int main()
//{
//	int choice = 1 , playerNo;
//	Player *array= new Player[3];
//	 inputs  of all users in start
//	for (int i = 0; i < 3; i++)
//	{
//		cout << "-------------------------------------\n";
//		cout << "Enter input of player " << i + 1 << endl;
//		cout << "-------------------------------------\n";
//		inputData(array[i]);
//	}
//	while (choice != 5)// start of menu driven 
//	{
//		cout << "\n-------------------------------------\n";
//		cout << "                Menu                 \n";
//
//		cout << "1. Search and update player contents.\n";
//		cout << "2. Input player contents.\n";
//		cout << "3. Output/Display players contents.\n";
//		cout << "4. Exit program\n";
//
//		cout << "Enter the choice (1 or 2 or 3 or 4): ";
//		cin >> choice;
//		while (choice != 1 && choice != 2 && choice != 3 && choice != 4)// if choice not 1 2 3 or 4 then invalid prompt 
//		{
//			cout << "\n Invalid input . Enter Again :";
//			cin >> choice;
//		}
//		switch (choice)
//		{
//		case 1:			//search and update 
//			searchPlayer(array);
//			break;
//
//		case 2:		//input again of user 
//			cout << "\n Enter player NUMBER whose data you want to input (1 or 2 or 3):";
//			cin >> playerNo;
//			while (playerNo != 1 && playerNo != 2 && playerNo != 3)
//			{
//				cout << "\n Invalid input . Enter Again :";
//				cin >> playerNo;
//			}
//			inputData(array[playerNo]);
//			break;
//
//		case 3:				// Display all data of all players  
//			displayData(array);
//			break;
//		case 4:		// to end program 
//			choice = 5;
//			break;
//		default:
//			cout << "\n Invalid Command !";
//		}
//	}
//	delete[] array;
//	system("pause");
//	return 0;
//}
//
//void inputData(Player& player)
//{
//	cout << "Enter name: ";
//	cin >> player.name;
//	cout << "Enter number of home runs: ";
//	cin >> player.no_of_home_runs;
//	cout << "Enter number of hits: ";
//	cin >> player.no_of_hits;
//}
//
//void searchPlayer(Player* player) 
//{
//	string name;
//	cout << "Enter the player name: ";
//	cin >> name;
//	for (int i = 0; i < 3; i++)
//	{
//		if (player[i].name == name) 
//		{
//			cout << "-------------------------------------\n";
//			cout << "Updating the player " << player[i].name << endl;
//			cout << "-------------------------------------\n";
//			inputData(player[i]);
//			cout << "-------------------------------------\n";
//		}
//		else 
//		{
//			cout << "The player name is not found.\n";
//		}
//	}
//}
//
//void displayData(Player* player) {
//	cout << "*************************************\n";
//	cout << "                Output is            \n";
//	cout << "-------------------------------------\n";
//	for (int i = 0; i < 3; i++)
//	{
//		cout << "-------------------------------------\n";
//		cout << "Output of player " << i + 1 << endl;
//		cout << "-------------------------------------\n";
//		cout << "Name: " << player[i].name << endl;
//		cout << "Number of home runs: " << player[i].no_of_home_runs << endl;
//		cout << "Number of hits: " << player[i].no_of_hits << endl;
//	}
//	cout << "*************************************\n";
//}
//
