//#include <iostream>
//using namespace std;
//// structure of data base
//
//struct Address
//{
//	int houseNo = 0;
//	int streetNo = 0;
//	string cityName;
//	string provinceName;
//};
//struct Student 
//{
//	string name;
//	Address address;
//	int age = 0;
//	double gpa = 0;
//};
////  main function 
//int main() 
//{
//	int num = 0;
//	cout << "------------------------------------------------------\n";
//	cout << "How many students data base you want to enter: ";
//	cin >> num;
//	cout << "------------------------------------------------------\n";
//	// making an dynamic structures 
//	Student * studentData = new Student [num];
//	// taking inputs
//	cout << "                       INPUTS                         \n";
//	for (int i = 0; i < num; i++) {
//		cout << "*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n";
//		cout << "                  Input Student " << i + 1 << " Details \n";
//		cout << "------------------------------------------------------\n";
//		cout << "Enter name of Student: ";
//		cin >> studentData[i].name;
//		cout << "Enter Age: ";
//		cin >> studentData[i].age;
//		cout << "Enter GPA: ";
//		cin >> studentData[i].gpa;
//		cout << "Enter House No. : ";
//		cin >> studentData[i].address.houseNo;
//		cout << "Enter Street No. : ";
//		cin >> studentData[i].address.streetNo;
//		cout << "Enter City Name: ";
//		cin >> studentData[i].address.cityName;
//		cout << "Enter Province Name: ";
//		cin >> studentData[i].address.provinceName;
//	}
//	cout << "*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n";
//	// display the outputs 
//	cout << "                     OUTPUTS                          \n";
//	cout << "------------------------------------------------------\n";
//	for (int i = 0; i < num; i++) 
//	{
//		cout << "              Student " << i + 1 << " Details \n";
//		cout << "------------------------------------------------------\n";
//		cout << "Name: " << studentData[i].name << "   Age: " << studentData[i].age << "   GPA: " << studentData[i].gpa << endl;
//		cout << "Address: House# " << studentData[i].address.houseNo << " Street# " << studentData[i].address.streetNo
//		     << " " << studentData[i].address.cityName << " " << studentData[i].address.provinceName << endl;
//			
//		cout << "*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n";
//	}
//	// Deallocation of DMA
//	delete[]studentData;
//	studentData = nullptr;
//	system("pause");
//	return 0;
//}
