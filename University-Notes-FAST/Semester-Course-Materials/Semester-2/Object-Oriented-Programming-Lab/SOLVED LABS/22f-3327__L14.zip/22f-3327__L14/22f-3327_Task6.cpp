#include <iostream>
using namespace std;
// class of Year
class YearInvalid {
	string wrongInput;
public:
	YearInvalid(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01() {
		return wrongInput;
	}
};
// class of month
class MonthInvalid {
	string wrongInput;
public:
	MonthInvalid(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01() {
		return wrongInput;
	}
};
// class of day
class DayInvalid {
	string wrongInput;
public:
	DayInvalid(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01() {
		return wrongInput;
	}
};
// prototype of function name change
string monthNameChange(int);
// main function
int main() {
	int day, month, year;
	bool run = true;
	while (run) {
		try {
			
			cout << "        INPUTS\n";
			
			cout << "Enter day : ";
			cin >> day;
			cout << "Enter month : ";
			cin >> month;
			cout << "Enter year : ";
			cin >> year;
		
			if (year < 0) {
				throw YearInvalid("Year input invalid\n");
			}
			if (month > 12 || month < 0) {
				throw MonthInvalid("Month input invalid\n");
			}
			if (day < 0 || day > 30) {
				throw DayInvalid("Day input invalid\n");
			}
			else run = false;
			
		}
		catch (YearInvalid obj) {
			cout << obj.wrongInput01();
		}
		catch (DayInvalid obj) {
			cout << obj.wrongInput01();
		}
		catch (MonthInvalid obj) {
			cout << obj.wrongInput01();
		}
	}
	cout << "Date of Birth : " << monthNameChange(month) << day << "," << year << endl;
	
	system("pause");
	return 0;
}

string monthNameChange(int i) {
	string month[] = { "January ", "Feburary ", "March ", "April ", "May ", "June ", "July ",
		"August ", "September ", "October ", "November ", "December " };
	return month[i - 1];
}
