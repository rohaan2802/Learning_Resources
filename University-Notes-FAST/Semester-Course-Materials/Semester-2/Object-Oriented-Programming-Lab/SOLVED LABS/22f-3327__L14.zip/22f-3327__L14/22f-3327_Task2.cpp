//#include <iostream>
//using namespace std;
//// prototypes of function
//int addFraction(int a, int b, int c, int d, int& nom, int& den)
//{
//    
//    nom = a * d + b * c;
//    den = b * d;
//    return nom;
//    return den;
//}
//int functionMultiply(int a, int b, int c, int d, int& nom, int& den)
//{
//    nom = a * c;
//    den = b * d;
//    return nom;
//    return den;
//}
//int subtractFraction(int a, int b, int c, int d, int& nom, int& den)
//{
//    nom = a * d - b * c;
//    den = b * d;
//    return nom;
//    return den;
//}
//int divideFraction(int a, int b, int c, int d, int& nom, int& den)
//{
//    nom = a * d;
//    den = b * c;
//    return nom;
//    return den;
//
//}
//void displayMenu() {
//    cout << "=============================\n";
//    cout << "            MENU\n";
//    cout << "=============================\n";
//    cout << "1. Addition.\n";
//    cout << "3. Subtraction \n";
//    cout << "2. Divisiom. \n";
//    cout << "=============================\n";
//}
//
//// main function
//int main() {
//    int nume01, nume02, denomi01, denomi02, choice = 0;
//    int nume03 = 0, denomi03 = 0;
//    displayMenu();
//    bool temp=true;
//    while (temp)
//    {
//        
//        try {
//            
//            cout << "Enter Choice: " << endl;
//            cin >> choice;
//            if (choice>3 || choice<1)
//            {
//                throw 1;
//            }
//            else
//                temp = false;
//
//        }
//        catch (int)
//        {
//            cout << "Enter Choice again: " << endl;
//            cin >> choice;
//        }
//    }
//    cout << "=============================\n";
//    cout << "           INPUTS\n";
//    cout << "=============================\n";
//    cout << "Enter numerator 1: ";
//    cin >> nume01;
//    cout << "Enter numerator 2: ";
//    cin >> nume02;
//    cout << "Enter Denominator 1: ";
//    cin >> denomi01;
//    cout << "Enter Denominator 2: ";
//    cin >> denomi02;
//    cout << "=============================\n";
//    switch (choice)
//    {
//    case 1:
//        addFraction(nume01, nume02, denomi01, denomi02, nume03, denomi03);
//        break;
//    case 2:
//        subtractFraction(nume01, nume02, denomi01, denomi02, nume03, denomi03);
//        break;
//    case 3:
//        divideFraction(nume01, nume02, denomi01, denomi02, nume03, denomi03);
//        break;
//    default:
//        cout << "\nInvaid input ;";
//    }
//    cout << "Result is: " << nume03 << "/" << denomi03 << endl;
//    cout << "=============================\n";
//    system("pause");
//    return 0;
//}
