//#include<iostream>
//using namespace std;
//// main function
//int main() {
//    int feet = -1;
//    double total = 0, inches = 0, centiMe = 0;
//    while (feet < 0 || inches < 0) {
//        cout << "======================\n";
//        cout << "       INPUTS\n";
//        cout << "======================\n";
//        cout << "Enter feet:";
//        cin >> feet;
//        cout << "Enter Inches: ";
//        cin >> inches;
//        cout << "======================\n";
//        try {
//            if (feet < 0) {
//                throw(feet);
//            }
//            if (inches < 0) {
//                throw(inches);
//            }
//            total = (feet * 12) + inches;
//            centiMe = total * 2.54;
//            cout << "feet and inches is converted into : " << centiMe << " centimeters." << endl;
//        }
//        catch (int feet) {
//            cout << "Invalid input for feet, please try again." << endl;
//        }
//        catch (double inches) {
//            cout << "Invalid input for inches, please try again." << endl;
//        }
//        cout << "======================\n";
//    }
//    system("pause");
//    return 0;
//}
