#include <iostream>
using namespace std;
// class of Year
class invalidHr
{
	string wrongInput;
public:
	invalidHr(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01()
	{
		return wrongInput;
	}
};
// class of month
class invalidMin
{
	string wrongInput;
public:
	invalidMin(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01() {
		return wrongInput;
	}
};
// class of hour
class invalidSec {
	string wrongInput;
public:
	invalidSec(string wrongInput) :wrongInput(wrongInput) {}
	string wrongInput01() {
		return wrongInput;
	}
};

// main function
int main() {
	int hour, minutes, seconds;
	char meridiem;
	bool run = true;
	while (run) {
		try {

			cout << "        INPUTS\n";

			cout << "\nEnter hour : ";
			cin >> hour;
			cout << "\nEnter minutes: ";
			cin >> minutes;
			cout << "\nEnter seconds: ";
			cin >>seconds;
			cout << "\nEnter meridiem (A.M/P.M):";
			cin >> meridiem;
			if (seconds < 0 ||seconds>60)
			{
				throw invalidHr("seconds input invalid\n");
			}
			if (minutes <0 || minutes >60) {
				throw invalidMin("minutes input invalid\n");
			}
			if (hour < 0 || hour > 12)
			{
				throw invalidSec("hour input invalid\n");
			}
			else run = false;

		}
		catch (invalidHr obj) {
			cout << obj.wrongInput01();
		}
		catch (invalidSec obj) {
			cout << obj.wrongInput01();
		}
		catch (invalidMin obj) {
			cout << obj.wrongInput01();
		}
	}
	// Convert to 24-hour notation
	if (meridiem == 'P' || meridiem == 'p') {
		hour = (hour == 12) ? 12 : hour + 12;
	}
	else {
		hour = (hour == 12) ? 0 : hour;
	}
	cout << "\n time in 24 hour notation is: " << hour << ":" << minutes << ":" << seconds<<endl;
	system("pause");
	return 0;
}

