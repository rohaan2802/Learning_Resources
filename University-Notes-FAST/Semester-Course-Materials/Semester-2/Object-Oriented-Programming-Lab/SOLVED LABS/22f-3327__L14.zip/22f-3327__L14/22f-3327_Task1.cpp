//#include <iostream>
//using namespace std;
//
//// function of division
//float divide(float num1, float num2) 
//{
//    if (num2 == 0)
//    {
//        throw 1;
//    }
//    return (num1 / num2);
//}
//
//// main function
//int main()
//{
//    //a)Divide by zero
//    float num1 = 0, num2 = 0, output = 0;
//    cout << "Enter numerator: ";
//    cin >> num1;
//    cout << "Enter denominator: ";
//    cin >> num2;
//    //catch exception in main function
//    try
//    {
//        output = divide(num1, num2);
//        cout << "The quotient is :" << output << endl;
//    }
//    catch (int)
//    {
//        cout << "Exception :Division by zero" << endl;
//    }
//    cout << "--------------------------------\n";
// // b) different types of exception
//    int option = 0;
//  
//    cout << "     Types of Exception\n";
//  
//    cout << "1. int  \n";
//    cout << "2. float \n";
//    cout << "3. string \n";
//    cout << "4. char \n";
//  
//    cout << "Select Option: ";
//    cin >> option;
//  
//    try {
//        switch (option)
//        {
//        case 1:
//            throw 1;
//            break;
//        case 2:
//            throw 1.25;
//            break;
//        case 3:
//            throw string("abc");
//            break;
//        case 4:
//            throw 'a';
//            break;
//        }
//    }
//    catch (int) 
//    {
//        cout << "Exception occured of int\n";
//    }
//    catch (double) 
//    {
//        cout << "Exception occured of float\n";
//    }
//    catch (string) 
//    {
//        cout << "Exception occured of string\n";
//    }
//    catch (char)
//    {
//        cout << "Exception occured of char\n";
//    }
//   
//    system("pause");
//    return 0;
//}
