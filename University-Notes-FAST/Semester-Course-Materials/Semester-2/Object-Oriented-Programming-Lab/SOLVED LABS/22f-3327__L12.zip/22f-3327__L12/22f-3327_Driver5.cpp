//#include<iostream>
//#include"22f-3327_Interface5.h"
//using namespace std;
//// main function
//int main() {
// 
//    cout << "                    CALCULATOR\n";
// 
//    Calculator<int, int> additon1(4, 8);
//    cout << "Addition of 4 + 8 is: " << additon1.addition() << endl;
//    Calculator<int, float> additon2(4, 4.5);
//    cout << "Addition of 4 + 4.5 is: " << additon2.addition() << endl;
//    Calculator<float, int> additon3(4.5, 4);
//    cout << "Addition of 4.5 + 4 is: " << additon3.addition() << endl;
//    Calculator<int, int> division1(8, 4);
//    cout << "Division of 8 \\ 4 is: " << division1.division() << endl;
//    Calculator<int, float> division2(8, 4.5);
//    cout << "Division of 8 \\ 4.5 is: " << division2.division() << endl;
//    Calculator<float, int> division3(8.5, 4);
//    cout << "Division of 8.5 \\ 4 is: " << division3.division() << endl;
//    Calculator<int, int> squareRoot1(16);
//    cout << "Square Root of 16 is: " << squareRoot1.squareRoot() << endl;
//    Calculator<float, float> squareRoot2(17.5);
//    cout << "Square Root of 17.5 is: " << squareRoot1.squareRoot() << endl;
//    system("pause");
//    return 0;
//}