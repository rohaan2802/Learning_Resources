#include<iostream>
#include"22f-3327_Interface4.h"
using namespace std;
int main()
{
	Triangle<int, float, int> obj1(4, 3.7, 4);
	cout << "Area is :" << obj1.Area();
	cout << "\nPerimeter is :" << obj1.Perimeter() << endl;
	system("pause");
	return 0;
}
