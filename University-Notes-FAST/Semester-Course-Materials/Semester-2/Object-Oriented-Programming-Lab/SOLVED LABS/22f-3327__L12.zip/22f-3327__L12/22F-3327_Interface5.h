//#pragma once
//#include <iostream>
//// template of class and outline functions
//template <class cal, class cal2>
//// class of Calculator
//class Calculator {
//private:
//    cal num1;
//    cal num2;
//public:
//    Calculator() :num1(0), num2(0) {};
//    Calculator(cal num1) :num1(num1), num2(0) {};
//    Calculator(cal num1, cal num2) :num1(num1), num2(num2) {};
//    cal addition();
//    cal subtraction();
//    cal multiplication();
//    cal division();
//    cal squareRoot();
//};
