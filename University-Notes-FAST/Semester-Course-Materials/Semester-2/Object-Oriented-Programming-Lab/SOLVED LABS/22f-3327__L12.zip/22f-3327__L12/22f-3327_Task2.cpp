//#include<iostream>
//using namespace std;
//template<class A>
//A average(A arr[], const int size)
//{
//	A sum = 0;
//	for (int i = 0; i < size; ++i)
//	{
//		sum += arr[i];
//	}
//	return sum / size;
//}
//int main()
//{
//	const int size = 4;
//	int intArr[size] = { 1,2,3,4 };
//	long longArr[size] = { 40000,50000,60000,70000 };
//	double doubleArr[size] = { 1.1,2.2,3.3,4.4 };
//
//	cout << "Average of Integer array:" << average(intArr, size) << endl;
//	cout << "Average of Long array:" << average(longArr, size) << endl;
//	cout << "Average of Double array:" << average(doubleArr, size) << endl;
//
//	system("pause");
//	return 0;
//}
