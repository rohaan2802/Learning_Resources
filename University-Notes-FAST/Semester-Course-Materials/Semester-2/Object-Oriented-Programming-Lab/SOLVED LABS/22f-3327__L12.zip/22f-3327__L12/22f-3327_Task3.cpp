//#include<iostream>
//#include<string>
//using namespace std;
//template<class A>
//void Swap(A& argument1, A& argument2)
//{
//	A temp = argument1;
//	argument1 = argument2;
//	argument2 = temp;
//}
//int main()
//{
//	int num1 = 6, num2 = 9;
//	float num3 = 1.56, num4 = 3.69;
//	char char1 = 'A', char2 = 'Z';
//	string string1 = "love", string2 = "taha";
//	cout << "Before swapping:" << num1 << " " << num2 << endl;
//	Swap(num1, num2);
//	cout << "After swapping:" << num1 << " " << num2 << endl << endl;
//	cout << "Before swapping:" << num3 << " " << num4;
//	Swap(num3, num4);
//	cout << "\nAfter swapping:" << num3 << " " << num4 << endl << endl;
//	cout << "Before swapping:" << char1 << " " << char2 << endl;
//	Swap(char1, char2);
//	cout << "After swapping:" << char1 << " " << char2 << endl << endl;
//	cout << "Before swapping:" << string1 << " " << string2 << endl;
//	Swap(string1, string2);
//	cout << "After swapping:" << string1 << " " << string2 << endl;
//	system("pause");
//	return 0;
//}
