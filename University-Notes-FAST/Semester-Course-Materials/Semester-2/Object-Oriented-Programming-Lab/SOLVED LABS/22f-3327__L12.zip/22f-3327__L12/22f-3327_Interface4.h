#pragma once
#include<iostream>
template <class A, class B, class C>
class Triangle
{
	A length;
	B width;
	C height;
public:
	Triangle();
	Triangle(A, B, C);
	float Area();
	float Perimeter();
};
