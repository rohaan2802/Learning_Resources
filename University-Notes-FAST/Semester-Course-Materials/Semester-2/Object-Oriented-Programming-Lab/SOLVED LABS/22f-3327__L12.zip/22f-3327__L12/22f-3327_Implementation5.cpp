//#include <iostream>
//#include"22F-3327_Interface5.h"
//#include<cmath>
//
//template <class cal, class cal2>
//cal Calculator<cal, cal2>::addition() {
//    return num1 + num2;
//}
//template<class cal, class cal2>
//cal Calculator<cal, cal2>::subtraction() {
//    return num1 - num2;
//}
//template <class cal, class cal2>
//cal Calculator<cal, cal2>::multiplication() {
//    return num1 * num2;
//}
//template <class cal, class cal2>
//cal Calculator<cal, cal2>::division() {
//    return num1 / num2;
//}
//template <class cal, class cal2>
//cal Calculator<cal, cal2>::squareRoot() {
//    return sqrt(num1);
//}
//
