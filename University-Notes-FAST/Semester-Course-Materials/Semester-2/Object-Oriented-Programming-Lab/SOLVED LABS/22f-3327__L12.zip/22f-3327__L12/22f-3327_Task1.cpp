//#include<iostream>
//using namespace std;
//template<class A>
//A add(A num1, A num2)
//{
//	return num1 + num2;
//}
//template <class B>
//B product(B num1, B num2)
//{
//	return num1 * num2;
//}
//int main()
//{
//	cout << "Addition of 5 and 6 is :" << add(5, 6);
//	cout << "\nAddition of 3.69 and 1.1 is :" << add(3.69, 1.1);
//	cout << "\nAddition of 5.123 and 6.456 is :" << add(5.123, 6.456);
//	cout << "\nProduct of 5 and 6 is :" << product(5, 6);
//	cout << "\nProduct of 3.1 and 3.9 is :" << product(3.1, 3.9);
//	cout << "\nProduct of 3.14 and 6.69 is :" << product(3.14, 6.69) << endl;
//	system("pause");
//	return 0;
//}
