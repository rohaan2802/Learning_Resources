#include<iostream>
#include"22f-3327_Interface4.h"
using namespace std;
template <class A, class B, class C>
Triangle<A,B,C> ::Triangle() 
{
	length = 0;
	width = 0;
	height = 0;
}
template <class A, class B, class C>
Triangle<A,B,C>::Triangle(A Length , B Width , C Height ) :length(Length), width(Width), height(Height) {}
template <class A, class B, class C>
float Triangle<A,B,C>::Area()
{
	return (1 / 2) * width * height;
}
template <class A, class B, class C>
float Triangle<A,B,C>::Perimeter()
{
	return length + width + height;
}

